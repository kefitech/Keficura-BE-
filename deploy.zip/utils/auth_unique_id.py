from apps.data_hub.models import * 
from datetime import datetime


'''Function For generating the next patient id '''
SECRET_OFFSET = 100000  # Need to  Keep this secret!
def get_next_patient_id():
    last_patient = PatientRegistration.objects.order_by('-id').first()
    if last_patient:
        next_num = int(last_patient.patient_id.split('-')[1]) + 1
    else:
        next_num = SECRET_OFFSET + 1
    return f"PAT-{str(next_num).zfill(3)}"




'''Function For generating the next Appointment id '''

def get_next_appointment_id():
    last_appointment = Appointment.objects.order_by('-id').first()
    if last_appointment:
        next_num = int(last_appointment.appointment_id.split('-')[1]) + 1
    else:
        next_num = 1
    return f"APPT-{str(next_num).zfill(3)}"


def get_next_bill_id(appointment):
    try:
        existing_bill = PatientBill.objects.get(appointment=appointment)
        return existing_bill.bill_number
    except PatientBill.DoesNotExist:
        pass
 
    last_bill = PatientBill.objects.order_by('-id').first()
    
    if last_bill and last_bill.bill_number.startswith('BIL-'):
        last_number = int(last_bill.bill_number.split('-')[1])
        next_number = last_number + 1
    else:
        next_number = 1
 
    return f"BIL-{str(next_number).zfill(3)}"
    

def get_next_pharma_bill_id():

    current_period = datetime.now().strftime('%Y%m')
    
    last_bill = PharmacyBilling.objects.filter(
        bill_number__startswith=f"PH-{current_period}"
    ).order_by('-bill_number').first()
    
    if last_bill:
        try:
            sequence_str = last_bill.bill_number.split('-')[-1]
            sequence = int(sequence_str) + 1
        except (ValueError, IndexError):
            
            sequence = 1
    else:
        
        sequence = 1
    
    return f"PH-{current_period}-{str(sequence).zfill(3)}"
    
    
def get_next_lab_bill_id():

    current_period = datetime.now().strftime('%Y%m')
    
    last_bill = LabBilling.objects.filter(
        bill_number__startswith=f"LB-{current_period}"
    ).order_by('-bill_number').first()
    
    if last_bill:
        try:
            sequence_str = last_bill.bill_number.split('-')[-1]
            sequence = int(sequence_str) + 1
        except (ValueError, IndexError):
            
            sequence = 1
    else:
        
        sequence = 1
    
    return f"LB-{current_period}-{str(sequence).zfill(3)}"




#=========================================================================================================================#
#                                          FUNCTIONS FOR NUMBERS TO WORDS CONVERSION                                      #
#=========================================================================================================================#

def num_to_words(num):
    """Convert a number to words representation"""
    
    def _convert_under_thousand(n):
        ones = ['', 'One', 'Two', 'Three', 'Four', 'Five', 'Six', 'Seven', 'Eight', 'Nine', 'Ten',
                'Eleven', 'Twelve', 'Thirteen', 'Fourteen', 'Fifteen', 'Sixteen', 'Seventeen', 'Eighteen', 'Nineteen']
        tens = ['', '', 'Twenty', 'Thirty', 'Forty', 'Fifty', 'Sixty', 'Seventy', 'Eighty', 'Ninety']
        
        if n < 20:
            return ones[n]
        elif n < 100:
            return tens[n // 10] + (' ' + ones[n % 10] if n % 10 != 0 else '')
        else:
            return ones[n // 100] + ' Hundred' + (' and ' + _convert_under_thousand(n % 100) if n % 100 != 0 else '')
    
    if num == 0:
        return 'Zero'
        
    # paise part
    rupees = int(num)
    paise = int(round((num - rupees) * 100))
    
    result = ''
    
    #  rupees part
    if rupees > 0:
        crore = rupees // 10000000
        rupees %= 10000000
        
        lakh = rupees // 100000
        rupees %= 100000
        
        thousand = rupees // 1000
        rupees %= 1000
        
        if crore > 0:
            result += _convert_under_thousand(crore) + ' Crore '
        
        if lakh > 0:
            result += _convert_under_thousand(lakh) + ' Lakh '
        
        if thousand > 0:
            result += _convert_under_thousand(thousand) + ' Thousand '
        
        if rupees > 0:
            result += _convert_under_thousand(rupees)
        
        result += ' Rupees'
    
    # Handle paise part
    if paise > 0:
        result += ' and ' + _convert_under_thousand(paise) + ' Paise'
        
    return result.strip()







