"""
Hospital Information System - Centralized Data Models
=====================================================

Author: Athul Gopan
Created: 2025
Description: Unified data models for the Hospital Management System.
            All models consolidated in a single app for better maintainability
            and reduced circular dependencies.

This module contains all core models for:
- User Management (System Creators, Administrators, Doctors, Nurses, Staff)
- Hospital Infrastructure (Departments, Specializations, Schedules)
- Patient Management (Registration, Appointments)
- Medical Services (Consultations, Prescriptions, Lab Tests)
- Pharmacy Operations (Medications, Stock, Dispensing)
- Billing Systems (Patient Bills, Pharmacy Bills, Lab Bills)
- Menu and Permissions Management

Note: All models inherit from Base abstract model which provides:
      - Audit fields (created_by, created_on, updated_by, updated_on)
      - Status tracking (is_active)
      - Comments field for additional notes
"""

from django.db import models
from django.contrib.auth.models import User
from django.utils.translation import gettext_lazy as _
from base_util.base import *
from django.core.validators import RegexValidator
from django.contrib.auth.models import Permission, Group



# ============================================================================
# USER MANAGEMENT MODELS
# ============================================================================
# Author: Athul Gopan
# Purpose: Models for system-level users and administrators
# ============================================================================

class SystemCreator(models.Model):
    """
    System Creator Model

    Represents the highest level of system access - the super administrator
    who has full control over the entire Hospital Information System.

    Usage:
        - Created during initial system setup
        - Has unrestricted access to all features
        - Can create and manage other administrators
        - Typically one per hospital system

    Fields:
        user: OneToOne relationship with Django User model
        is_superadmin: Boolean flag indicating superadmin status
    """
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    is_superadmin = models.BooleanField(default=True)

    def __str__(self):
        return f"System Creator: {self.user.username}"
    



class Administrator(Base):
    """
    Administrator Model

    Manages hospital administrators who have elevated privileges for
    system configuration and user management.

    Usage:
        - Created by SystemCreator
        - Manages hospital operations and staff
        - Can configure departments, schedules, and permissions
        - Has access to reports and analytics

    Fields:
        user: OneToOne relationship with Django User
        profile_picture: Administrator's profile photo
        phone_number: Unique contact number
        gender: Gender identification
        date_of_birth: Birth date for age verification
        date_joined: Employment start date
        employee_id: Unique employee identifier
        home_address: Residential address details
        qualification: Educational qualifications
        experience_years: Years of administrative experience
        experience_certificate: Document upload for verification
    """
    user = models.OneToOneField(User, on_delete=models.CASCADE)

    # Personal details
    profile_picture = models.ImageField(upload_to='admin_profiles/', null=True, blank=True)
    phone_number = models.CharField(max_length=15, unique=True)
    gender = models.CharField(max_length=10, choices=[('Male', 'Male'), ('Female', 'Female'), ('Other', 'Other')])
    date_of_birth = models.DateField(null=True, blank=True)
    date_joined = models.DateField(blank=True, null=True)

    # Work and role information
    employee_id = models.CharField(max_length=50, unique=True, blank=True)

    # Address Information
    home_address = models.TextField(null=True)
    home_city = models.CharField(max_length=100, null=True)
    home_state = models.CharField(max_length=100, blank=True, null=True)
    home_country = models.CharField(max_length=100, null=True)
    home_zip_code = models.CharField(max_length=20, null=True)

    # Professional credentials
    experience_certificate = models.FileField(upload_to='doctor_documents/', blank=True, null=True)
    qualification = models.CharField(max_length=255, null=True)
    experience_years = models.PositiveIntegerField(null=True)

    def __str__(self):
        return f"Administrator: {self.user.username}"
    


# ============================================================================
# CORE HOSPITAL INFRASTRUCTURE MODELS
# ============================================================================
# Author: Athul Gopan
# Purpose: Hospital structure, departments, and reusable status tracking
# ============================================================================

class Status(Base):
    """
    Universal Status Tracking Model

    A reusable status model for tracking various states across different
    modules of the hospital system.

    Usage:
        - Tracks status for appointments, billing, lab tests, etc.
        - Provides standardized status codes across the system
        - Categorized by module for easy filtering

    Fields:
        code: Unique status identifier (e.g., 'APPT_SCHEDULED')
        name: Human-readable status name
        description: Detailed explanation of the status
        category: Module category (Appointment, Billing, Lab, etc.)

    Example:
        Status(code='APPT_SCHEDULED', name='Scheduled', category='APPOINTMENT')
    """
    STATUS_CATEGORIES = [
        ('APPOINTMENT', 'Appointment'),
        ('BILLING', 'Billing'),
        ('LAB', 'Lab'),
        ('DISCHARGE', 'Discharge'),
        ('ADMISSION', 'Admission'),
        ('PRESCRIPTION', 'Prescription'),
        ('GENERIC', 'Generic'),
    ]
    code = models.CharField(max_length=50, unique=True)
    name = models.CharField(max_length=100)
    description = models.TextField(blank=True, null=True)
    category = models.CharField(max_length=50, choices=STATUS_CATEGORIES)

    class Meta:
        verbose_name_plural = "Statuses"
        unique_together = ('code', 'category')

    def __str__(self):
        return f"{self.name} ({self.category})"
    


class Department(Base):
    """
    Hospital Department Model

    Represents various departments within the hospital (e.g., Cardiology,
    Orthopedics, Emergency, Pediatrics).

    Usage:
        - Organizes doctors and specializations
        - Tracks physical location within hospital
        - Links to department head (Doctor)
        - Used for routing patients and appointments

    Fields:
        name: Department name (e.g., 'Cardiology')
        code: Short code for quick reference (e.g., 'CARD')
        description: Detailed department information
        head: Foreign key to Doctor who heads the department
        floor: Physical location (floor/wing)
        contact_number: Department contact phone
        email: Department email for inquiries
    """
    name = models.CharField(max_length=100, unique=True, null=True)
    code = models.CharField(max_length=10, unique=True, null=True)
    description = models.TextField(blank=True)
    head = models.ForeignKey('Doctor', on_delete=models.SET_NULL, null=True, blank=True, related_name='headed_departments')
    floor = models.CharField(max_length=20, blank=True, null=True)
    contact_number = models.CharField(max_length=15, blank=True, null=True)
    email = models.EmailField(blank=True, null=True)

    def __str__(self):
        return f"{self.name} ({self.code})"
    


class Specialization(Base):
    """
    Medical Specialization Model

    Represents specific medical specializations within departments.

    Usage:
        - Categorizes doctors by their expertise
        - Links to parent department
        - Used for appointment routing and doctor search

    Fields:
        name: Specialization name (e.g., 'Interventional Cardiology')
        code: Short identifier (e.g., 'INTCARD')
        description: Detailed description of specialization
        department: Parent department this specialization belongs to

    Example:
        Specialization(name='Interventional Cardiology', code='INTCARD',
                      department=cardiology_dept)
    """
    name = models.CharField(max_length=100, unique=True)
    code = models.CharField(max_length=10, unique=True, null=True)
    description = models.TextField(blank=True)
    department = models.ForeignKey(Department, on_delete=models.CASCADE, related_name='specializations', null=True)

    def __str__(self):
        return f"{self.name} ({self.code})"


# ============================================================================
# MEDICAL STAFF MODELS
# ============================================================================
# Author: Athul Gopan
# Purpose: Doctor, Nurse, and medical staff management
# ============================================================================

class Doctor(Base):
    """
    Doctor Model

    Represents medical practitioners in the hospital system.

    Usage:
        - Manages doctor profiles and credentials
        - Links to specialization and department
        - Stores consultation fees
        - Handles scheduling through DoctorSchedule
        - Used for appointments and consultations

    Fields:
        user: OneToOne link to Django User (for authentication)
        date_of_birth: Doctor's birth date
        gender: Gender identification
        contact_number: Primary contact
        phone_number: Alternate contact
        email: Professional email
        home_address: Full residential address
        qualification: Medical degrees and certifications
        experience_years: Years of medical practice
        profile_picture: Doctor's photo for patient reference
        specialization: Medical specialization (ForeignKey)
        date_joined: Hospital joining date
        curriculum_vitae: CV document upload
        education_certificate: Degree certificates
        experience_certificate: Experience proof documents
        doctor_consultation_fee: Fee charged per consultation

    Related Models:
        - DoctorSchedule: Weekly availability schedule
        - Appointment: Patient appointments
        - DoctorConsultation: Medical consultations performed
    """
    user = models.OneToOneField(User, on_delete=models.CASCADE, null=True)

    # Personal Information
    date_of_birth = models.DateField(null=True)
    gender = models.CharField(max_length=10, choices=[
        ('MALE', 'Male'),
        ('FEMALE', 'Female'),
        ('OTHER', 'Other')
    ], null=True)

    # Contact Information
    contact_number = models.CharField(max_length=15)
    phone_number = models.CharField(max_length=15, blank=True, null=True)
    email = models.EmailField()

    # Home Address
    home_address = models.TextField(null=True)
    home_city = models.CharField(max_length=100, null=True)
    home_state = models.CharField(max_length=100, blank=True, null=True)
    home_country = models.CharField(max_length=100, null=True)
    home_zip_code = models.CharField(max_length=20, null=True)

    # Professional Information
    qualification = models.CharField(max_length=255, null=True)
    experience_years = models.PositiveIntegerField(null=True)
    profile_picture = models.ImageField(upload_to='doctors/', blank=True, null=True)
    specialization = models.ForeignKey(Specialization, on_delete=models.SET_NULL, null=True)
    date_joined = models.DateField(blank=True, null=True)

    # Documents
    curriculum_vitae = models.FileField(upload_to='doctor_documents/', blank=True, null=True)
    education_certificate = models.FileField(upload_to='doctor_documents/', blank=True, null=True)
    experience_certificate = models.FileField(upload_to='doctor_documents/', blank=True, null=True)

    # Payment information
    doctor_consultation_fee = models.DecimalField(max_digits=10, decimal_places=2, null=True)

    def __str__(self):
        return f"Dr. {self.user.first_name} {self.user.last_name}"
    



class DoctorSchedule(Base):
    """
    Doctor Schedule Model

    Manages weekly availability schedules for doctors.

    Usage:
        - Defines doctor's working hours for each day
        - Used by appointment system to check availability
        - Supports multiple shifts per day
        - Includes validity period for temporary schedules

    Fields:
        doctor: Foreign key to Doctor
        day_of_week: Day of the week (Monday-Sunday)
        shift_type: Type of shift (Morning/Afternoon/Evening/Night/Full Day)
        start_time: Shift start time
        end_time: Shift end time
        room_number: Assigned consultation room
        max_appointments: Maximum appointments allowed per shift
        valid_from: Schedule validity start date (optional)
        valid_to: Schedule validity end date (optional)

    Business Logic:
        - Unique constraint on (doctor, day_of_week, shift_type)
        - Used for preventing appointment conflicts
        - Supports temporary schedules via valid_from/valid_to
    """
    doctor = models.ForeignKey(Doctor, on_delete=models.CASCADE, related_name='schedules')
    day_of_week = models.CharField(max_length=10, choices=[
        ('MONDAY', 'Monday'),
        ('TUESDAY', 'Tuesday'),
        ('WEDNESDAY', 'Wednesday'),
        ('THURSDAY', 'Thursday'),
        ('FRIDAY', 'Friday'),
        ('SATURDAY', 'Saturday'),
        ('SUNDAY', 'Sunday'),
    ], null=True)

    shift_type = models.CharField(max_length=20, choices=[
        ('MORNING', 'Morning'),
        ('AFTERNOON', 'Afternoon'),
        ('EVENING', 'Evening'),
        ('NIGHT', 'Night'),
        ('FULL_DAY', 'Full Day'),
        ('CUSTOM', 'Custom'),
    ], default='CUSTOM', null=True)

    start_time = models.TimeField(null=True)
    end_time = models.TimeField(null=True)
    room_number = models.CharField(max_length=50, blank=True, null=True)
    max_appointments = models.PositiveIntegerField(null=True, blank=True)
    valid_from = models.DateField(null=True, blank=True)
    valid_to = models.DateField(null=True, blank=True)

    class Meta:
        unique_together = ('doctor', 'day_of_week', 'shift_type')
        ordering = ['doctor', 'day_of_week', 'start_time']

    def __str__(self):
        return f"{self.doctor} - {self.day_of_week} ({self.shift_type})"
    


# ============================================================================
# PATIENT AND APPOINTMENT MODELS
# ============================================================================
# Author: Athul Gopan
# Purpose: Patient registration and appointment management
# ============================================================================

class Appointment(Base):
    """
    Appointment Model

    Core model for managing patient appointments with doctors.

    Usage:
        - Scheduled by front desk or patients
        - Tracks patient journey from scheduling to completion
        - Supports follow-up appointments
        - Integrated with billing and pharmacy workflows

    Fields:
        appointment_id: Unique appointment identifier
        patient: Foreign key to PatientRegistration
        doctor: Foreign key to Doctor
        appointment_date: Scheduled date
        appointment_time: Scheduled time
        visit_reason: Patient's reason for visit
        visit_status: Current status in the workflow
        consultation_room: Assigned room number
        parent_consultation: Link to previous consultation (for follow-ups)
        is_follow_up: Flag indicating if this is a follow-up appointment

    Workflow States:
        SCHEDULED → CHECKED_IN → IN_CONSULTATION → PRESCRIPTION_READY →
        AT_PHARMACY → DISPENSED → AT_BILLING → PAYMENT_COMPLETE → COMPLETED

    Related Models:
        - DoctorConsultation: Medical consultation details
        - PatientBill: Billing information
        - MedicationDispense: Pharmacy dispensing records
    """

    appointment_id = models.CharField(max_length=50, unique=True)
    patient = models.ForeignKey('PatientRegistration', on_delete=models.CASCADE, related_name='appointments')
    doctor = models.ForeignKey(Doctor, on_delete=models.CASCADE, related_name='appointments')
    appointment_date = models.DateField()
    appointment_time = models.TimeField()
    visit_reason = models.TextField(null=True, blank=True)
    visit_status = models.CharField(max_length=30, choices=[
        ('SCHEDULED', 'Scheduled'),
        ('FOLLOW_UP', 'Follow-up'),
        ('CHECKED_IN', 'Checked In'),
        ('IN_CONSULTATION', 'In Consultation'),
        ('PRESCRIPTION_READY', 'Prescription Ready'),
        ('AT_PHARMACY', 'At Pharmacy'),
        ('DISPENSED', 'Medications Dispensed'),
        ('AT_BILLING', 'At Billing'),
        ('PAYMENT_COMPLETE', 'Payment Complete'),
        ('COMPLETED', 'Completed'),
        ('CANCELED', 'Canceled'),
    ], default='SCHEDULED')

    consultation_room = models.CharField(max_length=20, null=True, blank=True)

    # Follow-up tracking
    parent_consultation = models.ForeignKey('DoctorConsultation', null=True, blank=True, on_delete=models.SET_NULL, related_name='follow_up_appointments')
    is_follow_up = models.BooleanField(default=False)

    def __str__(self):
        return f"{self.patient.first_name}'s appointment with Dr. {self.doctor.user.last_name} on {self.appointment_date}"
    


# ============================================================================
# SUPPORT STAFF MODELS
# ============================================================================
# Author: Athul Gopan
# Purpose: Front desk, pharmacists, and administrative staff
# ============================================================================

class FrontDeskStaff(Base):
    """
    Front Desk Staff Model

    Manages reception and front desk staff who handle patient registration,
    appointments, and initial patient interactions.

    Usage:
        - Registers new patients
        - Schedules appointments
        - Manages patient check-in/check-out
        - Handles billing and payment collection
        - First point of contact for patients

    Fields:
        user: OneToOne link to Django User
        date_of_birth: Birth date
        gender: Gender identification
        contact_number: Primary contact
        emergency_contact: Emergency contact number
        email: Professional email
        employee_id: Unique staff identifier
        hire_date: Employment start date
        department: Department assignment (Reception/Billing/etc.)
        employment_type: Full-time, Part-time, or Contract
        shift_schedule: Work shift timings
        profile_picture: Staff photo
        signature: Digital signature for documents
        is_active: Employment status flag
    """
    user = models.OneToOneField(User, on_delete=models.CASCADE, null=True)

    # Personal Details
    date_of_birth = models.DateField(null=True, blank=True)
    gender = models.CharField(max_length=10,
                            choices=[('MALE', 'Male'), ('FEMALE', 'Female'), ('OTHER', 'Other')],
                            null=True, blank=True)

    # Contact Info
    contact_number = models.CharField(max_length=15)
    emergency_contact = models.CharField(max_length=15, blank=True)
    email = models.EmailField()

    # Employment Details
    employee_id = models.CharField(max_length=20, unique=True)
    hire_date = models.DateField()
    department = models.CharField(max_length=50,
                                 choices=[
                                     ('RECEPTION', 'Reception'),
                                     ('BILLING', 'Billing'),
                                     ('APPOINTMENT', 'Appointment Scheduling'),
                                     ('PATIENT_SERVICES', 'Patient Services')
                                 ], null=True)
    employment_type = models.CharField(max_length=20,
                                      choices=[
                                          ('FULL', 'Full-time'),
                                          ('PART', 'Part-time'),
                                          ('CONTRACT', 'Contract')
                                      ],
                                      default='FULL')

    # Administrative Fields
    shift_schedule = models.CharField(max_length=100,
                                     help_text="E.g., Morning, Evening, Night")

    # Profile Management
    profile_picture = models.ImageField(upload_to='front_desk_staff/', blank=True, null=True)
    signature = models.ImageField(upload_to='signatures/', blank=True, null=True)

    # Status
    is_active = models.BooleanField(default=True)

    def __str__(self):
        return f"Front Desk Staff {self.user.get_full_name()} - {self.employee_id}"

    class Meta:
        ordering = ['user__last_name']
        verbose_name = 'FrontDeskStaff'
        verbose_name_plural = 'FrontDeskStaff'



# ============================================================================
# HOSPITAL CONFIGURATION MODELS
# ============================================================================
# Author: Athul Gopan
# Purpose: Hospital profile and organizational settings
# ============================================================================

class Hospital(Base):
    """
    Hospital Model

    Stores hospital/organization profile and configuration details.

    Usage:
        - Central repository for hospital information
        - Used in reports, bills, and official documents
        - Manages licensing and accreditation details
        - Supports multi-hospital systems

    Fields:
        name: Official hospital name
        hospital_code: Unique hospital identifier
        street_address/city/state/postal_code/country: Physical address
        phone_number/email/website: Contact information
        hospital_type: Classification (General/Specialty/Clinic/Teaching)
        emergency_services: Boolean flag for ER availability
        license_number: Government license number
        accreditation: Accreditation details
        license_expiry_date: License validity date
        established_date: Hospital establishment date
        bed_capacity: Total bed capacity
        logo: Hospital logo for branding
    """
    # Basic Information
    name = models.CharField(max_length=255, unique=True)
    hospital_code = models.CharField(max_length=50, unique=True)
    
    # Address Information
    street_address = models.CharField(max_length=255)
    city = models.CharField(max_length=100)
    state = models.CharField(max_length=100)
    postal_code = models.CharField(max_length=20)
    country = models.CharField(max_length=100, default='India')
    
    # Contact Information
    phone_regex = RegexValidator(
        regex=r'^\+?1?\d{9,15}$',
        message="Phone number must be entered in the format: '+999999999'"
    )
    phone_number = models.CharField(validators=[phone_regex], max_length=17, blank=True)
    email = models.EmailField(blank=True)
    website = models.URLField(blank=True)
    
    # Hospital Metadata
    HOSPITAL_TYPES = (
        ('G', 'General'),
        ('S', 'Specialty'),
        ('C', 'Clinic'),
        ('T', 'Teaching'),
    )
    hospital_type = models.CharField(max_length=1, choices=HOSPITAL_TYPES)
    
    # OWNERSHIP_TYPES = (
    #     ('PUB', 'Public'),
    #     ('PVT', 'Private'),
    #     ('GOV', 'Government'),
    #     ('NGO', 'Non-profit'),
    # )
    # ownership = models.CharField(max_length=5, choices=OWNERSHIP_TYPES)
    
    # Services Information
    emergency_services = models.BooleanField(default=False)
    # specialties = models.ManyToManyField('Specialty', blank=True)
    
    # Licensing and Certification
    license_number = models.CharField(max_length=100, unique=True,null=True)
    accreditation = models.CharField(max_length=100, null=True)
    license_expiry_date = models.DateField()
    
    # Additional Information
    description = models.TextField(blank=True)
    established_date = models.DateField(null=True, blank=True)
    bed_capacity = models.PositiveIntegerField(null=True, blank=True)
    logo = models.ImageField(upload_to='hospital_logos/', blank=True)
    
    # Geo Location (requires GeoDjango)
    # location = models.PointField(null=True, blank=True)
    
    # Timestamps

    def __str__(self):
        return self.name

    class Meta:
        ordering = ['name']
        verbose_name = 'Hospital'
        verbose_name_plural = 'Hospitals'


# ============================================================================
# MENU AND PERMISSIONS MODELS
# ============================================================================
# Author: Athul Gopan
# Purpose: Dynamic menu system and role-based access control
# ============================================================================

class MenuType(Base):
    """
    Menu Type Model

    Categorizes menu items by type (e.g., Main Menu, User Menu, Admin Menu).

    Usage:
        - Organizes menu structure
        - Supports different menu contexts
    """
    name = models.CharField(max_length=100)
    code = models.CharField(max_length=50, unique=True)
    description = models.CharField(max_length=500)

    class Meta:
        db_table = "menu_type"
        verbose_name = "MenuType"
        verbose_name_plural = "MenuTypes"

    def __str__(self):
        return self.name


class Menu(Base):
    """
    Menu Model

    Defines hierarchical navigation menu structure with role-based access.

    Usage:
        - Creates dynamic menu based on user permissions
        - Supports parent-child menu hierarchy
        - Links to features and URLs
        - Controls UI navigation access

    Fields:
        name: Menu item name
        title: Display title
        code: Unique menu identifier
        parent: Parent menu for hierarchical structure
        menu_type: Menu category
        redirect_url: Target URL/route
        icon: Icon class for UI display
        menu_order: Display order
        feature_code: Feature identifier for permission mapping
    """
    name = models.CharField(max_length=100)
    title = models.CharField(max_length=100)
    code = models.CharField(max_length=50, unique=True)
    parent = models.ForeignKey("self", on_delete=models.CASCADE, null=True, blank=True)
    menu_type = models.ForeignKey(MenuType, on_delete=models.CASCADE, null=True, blank=True)
    redirect_url = models.CharField(max_length=100)
    icon = models.CharField(max_length=100)
    menu_order = models.IntegerField()
    description = models.CharField(max_length=500)
    feature_code = models.CharField(max_length=50, null=True, blank=True)

    class Meta:
        db_table = "menu"
        verbose_name = "Menu"
        verbose_name_plural = "Menus"

    def __str__(self):
        return self.name


class MenuPermissionMapper(Base):
    """
    Menu Permission Mapper

    Maps menu items to user groups for role-based access control.

    Usage:
        - Controls which user groups can see which menus
        - Implements role-based menu visibility
    """
    menu = models.ForeignKey(Menu, on_delete=models.CASCADE)
    auth_group_permission = models.ForeignKey(
        Group, on_delete=models.CASCADE, null=True, blank=True
    )
    description = models.CharField(max_length=500)

    class Meta:
        db_table = "menu_permision"
        verbose_name = "Menu Permission"
        verbose_name_plural = "Menu Permissions"


# ============================================================================
# NURSING STAFF MODELS
# ============================================================================
# Author: Athul Gopan
# Purpose: Nurse management and shift scheduling
# ============================================================================

class Nurse(Base):
    """
    Nurse Model

    Manages nursing staff profiles and qualifications.

    Usage:
        - Stores nurse credentials and contact information
        - Links to shift assignments via NurseShiftAssignment
        - Supports department-wise nurse allocation

    Fields:
        user: OneToOne link to Django User
        date_of_birth: Birth date
        gender: Gender identification
        contact_number: Primary contact
        email: Professional email
        qualification: Nursing qualifications and certifications
        experience_years: Years of nursing experience
        profile_picture: Nurse's photo
    """
    user = models.OneToOneField(User, on_delete=models.CASCADE, null=True)

    # Personal Details
    date_of_birth = models.DateField(null=True)
    gender = models.CharField(max_length=10, choices=[('MALE', 'Male'), ('FEMALE', 'Female'), ('OTHER', 'Other')], null=True)

    # Contact Info
    contact_number = models.CharField(max_length=15)
    email = models.EmailField()

    # Qualifications and experience
    qualification = models.CharField(max_length=255, null=True)
    experience_years = models.PositiveIntegerField(null=True)
    profile_picture = models.ImageField(upload_to='nurses/', blank=True, null=True)

    def __str__(self):
        return f"Nurse {self.user.first_name} {self.user.last_name}"
    



class NurseShiftAssignment(Base):
    """
    Nurse Shift Assignment Model

    Manages daily shift assignments for nurses to departments.

    Usage:
        - Assigns nurses to specific departments and shifts
        - Tracks daily roster and nurse availability
        - Supports multiple shift types
        - Used for workload distribution

    Fields:
        nurse: Foreign key to Nurse
        department: Department assignment
        day: Specific date for this shift
        shift_type: Type of shift (Morning/Afternoon/Evening/Night)
        start_time: Shift start time
        end_time: Shift end time
        room_number: Assigned station/room

    Business Logic:
        - Prevents double-booking via unique_together constraint
        - Ordered by day and start time for roster view
    """
    nurse = models.ForeignKey(Nurse, on_delete=models.CASCADE, related_name='shift_assignments')
    department = models.ForeignKey(Department, on_delete=models.SET_NULL, null=True, related_name='nurse_assignments')

    day = models.DateField()

    shift_type = models.CharField(max_length=20, choices=[
        ('MORNING', 'Morning'),
        ('AFTERNOON', 'Afternoon'),
        ('EVENING', 'Evening'),
        ('NIGHT', 'Night'),
        ('FULL_DAY', 'Full Day'),
        ('CUSTOM', 'Custom'),
    ], default='FULL_DAY')

    start_time = models.TimeField(null=True, blank=True)
    end_time = models.TimeField(null=True, blank=True)

    room_number = models.CharField(max_length=50, blank=True, null=True)

    class Meta:
        unique_together = ('nurse', 'day', 'shift_type')
        ordering = ['day', 'start_time']

    def __str__(self):
        return f"{self.nurse} - {self.department} - {self.day} ({self.shift_type})"
    


class PatientRegistration(Base):
    """
    Patient Registration Model

    Central repository for patient demographic and contact information.

    Usage:
        - Registers new patients in the system
        - Stores demographic details and medical history
        - Links to appointments, consultations, and billing
        - Maintains emergency contact information

    Fields:
        patient_id: Unique patient identifier (auto-generated or manual)
        first_name/last_name: Patient name
        date_of_birth: Birth date for age calculation
        age: Calculated or manually entered age
        gender: Gender (Male/Female/Other)
        contact_number: Primary contact
        email: Email address
        address: Residential address
        allergies: Known allergies (important for prescriptions)
        emergency_contact: Emergency contact person details
        registration_date: Date of registration
        registration_type: Type of registration (OPD/IPD/Emergency)
        insurance_provider: Insurance company name
        insurance_number: Policy number

    Related Models:
        - Appointment: Patient appointments
        - DoctorConsultation: Medical consultations
        - PatientBill: Billing records
    """
    GENDER_CHOICES = [
        ('M', 'Male'),
        ('F', 'Female'),
        ('O', 'Other'),
    ]
    patient_id = models.CharField(max_length=50, unique=True)
    first_name = models.CharField(max_length=100, null=True, blank=True)
    last_name = models.CharField(max_length=100, null=True, blank=True)
    date_of_birth = models.DateField()
    age = models.IntegerField(null=True)
    gender = models.CharField(max_length=1, choices=GENDER_CHOICES)
    contact_number = models.CharField(max_length=15)
    email = models.EmailField(blank=True, null=True)
    address = models.TextField(blank=True, null=True)
    allergies = models.TextField(blank=True, null=True)
    emergency_contact = models.CharField(max_length=100, null=True)
    registration_date = models.DateField()
    registration_type = models.CharField(max_length=50, null=True)
    insurance_provider = models.CharField(max_length=100, null=True)
    insurance_number = models.CharField(max_length=50, null=True)

    def __str__(self):
        return f"{self.first_name} {self.last_name} ({self.patient_id})"
    

# ============================================================================
# PHARMACY MODELS
# ============================================================================
# Author: Athul Gopan
# Purpose: Medication management, stock control, and dispensing
# ============================================================================

class PharmacistStaff(Base):
    """
    Pharmacist Staff Model

    Manages pharmacist profiles and employment details.

    Usage:
        - Stores pharmacist credentials
        - Used for medication dispensing authorization
        - Links to pharmacy billing and stock management
    """
    user = models.OneToOneField(User, on_delete=models.CASCADE, null=True)
    
    # Personal Details
    date_of_birth = models.DateField(null=True, blank=True)
    gender = models.CharField(max_length=10,
                            choices=[('MALE', 'Male'), ('FEMALE', 'Female'), ('OTHER', 'Other')],
                            null=True, blank=True)
 
    # Contact Info
    contact_number = models.CharField(max_length=15)
    emergency_contact = models.CharField(max_length=15, blank=True)
    email = models.EmailField()
 
    # Employment Details
    employee_id = models.CharField(max_length=20, unique=True, null=True)
    hire_date = models.DateField()

    profile_picture = models.ImageField(upload_to='front_desk_staff/', blank=True, null=True)
    # signature = models.ImageField(upload_to='signatures/', blank=True, null=True)
    
    # Status
    is_active = models.BooleanField(default=True)
    
    def __str__(self):
        return f"Pharmacist {self.user.get_full_name()} - {self.employee_id}"

    class Meta:
        ordering = ['user__last_name']
        verbose_name = 'Pharmacist Staff'
        verbose_name_plural = 'Pharmacist Staff'


class Medication(Base):
    """
    Medication Master Model - ENHANCED

    Master list of all medications available in the hospital pharmacy.

    Usage:
        - Maintains medication catalog
        - Used in prescriptions and stock management
        - Links to stock entries and dispensing records
        - Stores reorder configuration

    Fields:
        name: Generic/brand name of medication
        description: Medication details and uses
        dosage_form: Form (tablet, capsule, syrup, injection)
        strength: Medication strength (e.g., '500mg', '10ml')

        NEW FIELDS:
        generic_name: Generic name of the medication
        brand_name: Brand/commercial name
        therapeutic_category: Category (Antibiotic, Analgesic, etc.)
        base_unit: Default unit for this medication
        default_reorder_level: Default minimum stock level
        default_reorder_quantity: Default reorder quantity
        requires_prescription: Whether prescription is mandatory
        is_refrigerated: Cold chain requirement
    """
    name = models.CharField(max_length=200)
    description = models.TextField(null=True, blank=True)
    dosage_form = models.CharField(max_length=100)
    strength = models.CharField(max_length=50)

    # NEW: Additional medication details
    # generic_name = models.CharField(max_length=200, null=True, blank=True, help_text="Generic name")
    # brand_name = models.CharField(max_length=200, null=True, blank=True, help_text="Brand name")
    # therapeutic_category = models.CharField(max_length=100, null=True, blank=True,
    #                                        help_text="e.g., Antibiotic, Analgesic")

    # NEW: Unit configuration
    # base_unit = models.ForeignKey('MedicationUnit', on_delete=models.SET_NULL, null=True, blank=True,
                                #   related_name='medications', help_text="Default unit (Tablet, ML, etc.)")

    # NEW: Reorder defaults
    # default_reorder_level = models.PositiveIntegerField(default=50, help_text="Default minimum stock level")
    # default_reorder_quantity = models.PositiveIntegerField(default=100, help_text="Default reorder quantity")

    # NEW: Flags
    # requires_prescription = models.BooleanField(default=True, help_text="Requires doctor's prescription")
    # is_refrigerated = models.BooleanField(default=False, help_text="Requires cold storage")
    # is_controlled_substance = models.BooleanField(default=False, help_text="Narcotic/controlled drug")

    def __str__(self):
        return f"{self.name} {self.strength} ({self.dosage_form})"

    def get_total_stock(self):
        """Get total stock across all batches"""
        return sum(stock.quantity for stock in self.stock_entries.filter(is_active=True))

    def get_available_stock(self):
        """Get available stock (non-expired batches)"""
        from datetime import datetime
        return sum(stock.quantity for stock in self.stock_entries.filter(
            is_active=True,
            expiry_date__gte=datetime.now().date()
        ))


# ============================================================================
# MEDICAL CONSULTATION MODELS
# ============================================================================
# Author: Athul Gopan
# Purpose: Doctor consultations, prescriptions, and medical records
# ============================================================================

class DoctorConsultation(Base):
    """
    Doctor Consultation Model

    Records medical consultations performed by doctors.

    Usage:
        - Stores diagnosis and treatment plan
        - Links prescriptions to appointments
        - Tracks recommended tests
        - Supports follow-up scheduling

    Fields:
        appointment: Foreign key to Appointment
        diagnosis: Doctor's diagnosis
        recommended_tests: JSON array of lab tests recommended
        doctor_notes: Additional notes from doctor
        follow_up_date: Next appointment date if required
        prescribed_medicines: ManyToMany to Medication via PrescribedMedicine

    Related Models:
        - PrescribedMedicine: Detailed prescription information
        - PatientBill: Billing for consultation
    """
    appointment = models.ForeignKey(Appointment, on_delete=models.CASCADE, related_name='consultations')
    diagnosis = models.TextField()
    recommended_tests = models.JSONField(default=list, blank=True)
    doctor_notes = models.TextField(blank=True, null=True)
    follow_up_date = models.DateField(blank=True, null=True)
    prescribed_medicines = models.ManyToManyField(Medication, through='PrescribedMedicine')

    def __str__(self):
        return f"Consultation for {self.appointment.patient.first_name} on {self.appointment.appointment_date}"
    

class PrescribedMedicine(Base):
    """
    Prescribed Medicine Model

    Through model for DoctorConsultation and Medication relationship.
    Stores detailed prescription instructions.

    Usage:
        - Links consultation to prescribed medications
        - Stores dosage, frequency, and duration
        - Used by pharmacy for dispensing

    Fields:
        consultation: Foreign key to DoctorConsultation
        medicine: Foreign key to Medication
        dosage: Dosage instruction (e.g., '1 tablet')
        frequency: How often (e.g., 'Twice daily')
        duration: Treatment duration (e.g., '7 days')
        quantity: Total quantity to dispense
        instructions: Special instructions for patient
    """
    consultation = models.ForeignKey(DoctorConsultation, on_delete=models.CASCADE)
    medicine = models.ForeignKey(Medication, on_delete=models.CASCADE)
    dosage = models.CharField(max_length=100)
    frequency = models.CharField(max_length=100)
    duration = models.CharField(max_length=100)
    quantity = models.PositiveIntegerField()
    instructions = models.TextField(blank=True, null=True)

    def __str__(self):
        return f"{self.medicine.name} for {self.consultation.appointment.patient.first_name}"


class MedicationStock(Base):
    """
    Medication Stock Model - ENHANCED

    Manages pharmacy inventory with batch-wise tracking.

    Usage:
        - Tracks medication inventory by batch
        - Manages expiry dates for stock rotation
        - Stores pricing information
        - Links to dispensing records
        - Tracks opening stock, received, sold, and balance quantities

    Fields:
        medication: Foreign key to Medication
        batch_number: Manufacturer batch number
        quantity: Current available quantity in stock
        expiry_date: Expiration date
        received_date: Stock received date
        purchase_price: Procurement cost
        selling_price: Retail price
        supplier: Supplier name (kept for backward compatibility)
        supplier_fk: Foreign key to Supplier model (NEW)
        manufacturer: Manufacturer name

        NEW FIELDS:
        opening_quantity: Opening stock quantity
        received_quantity: Total quantity received
        sold_quantity: Total quantity sold
        returned_quantity: Total quantity returned
        damaged_quantity: Total quantity damaged
        adjusted_quantity: Total adjustments (+/-)
        grn: Link to GRN that created this stock

    Business Logic:
        - Track FIFO/FEFO for stock rotation
        - Alert on low stock or near-expiry items
        - Formula: current_quantity = opening + received - sold - returned - damaged + adjusted
    """
    medication = models.ForeignKey(Medication, on_delete=models.CASCADE, related_name='stock_entries')
    batch_number = models.CharField(max_length=100)

    # Current quantity
    quantity = models.PositiveIntegerField()

    # NEW: Detailed quantity tracking
    opening_quantity = models.PositiveIntegerField(default=0, help_text="Opening stock")
    received_quantity = models.PositiveIntegerField(default=0, help_text="Total received")
    sold_quantity = models.PositiveIntegerField(default=0, help_text="Total sold")
    returned_quantity = models.PositiveIntegerField(default=0, help_text="Total returned to supplier")
    damaged_quantity = models.PositiveIntegerField(default=0, help_text="Total damaged/written off")
    adjusted_quantity = models.IntegerField(default=0, help_text="Adjustments (+/-)")

    # Dates
    expiry_date = models.DateField()
    received_date = models.DateField()

    # Pricing
    purchase_price = models.DecimalField(max_digits=10, decimal_places=2)
    selling_price = models.DecimalField(max_digits=10, decimal_places=2)
    mrp = models.DecimalField(max_digits=10, decimal_places=2, null=True, blank=True, help_text="Maximum Retail Price")

    # Supplier info (keeping old field for backward compatibility)
    supplier = models.CharField(max_length=200)

    manufacturer = models.CharField(max_length=200, default='Medi power')

    # NEW: Link to GRN


    # NEW: Alert flags (auto-calculated)
    is_near_expiry = models.BooleanField(default=False, help_text="Expiring within 3 months")
    is_expired = models.BooleanField(default=False, help_text="Already expired")
    is_low_stock = models.BooleanField(default=False, help_text="Below reorder level")
    is_out_of_stock = models.BooleanField(default=False, help_text="Stock is completely out (quantity = 0)")

    def __str__(self):
        return f"{self.medication.name} - Batch {self.batch_number} (Expires {self.expiry_date})"

    def get_current_stock(self):
        """Calculate current stock based on all transactions"""
        return (self.opening_quantity + self.received_quantity -
                self.sold_quantity - self.returned_quantity -
                self.damaged_quantity + self.adjusted_quantity)

    def days_to_expiry(self):
        """Calculate days until expiry"""
        from datetime import datetime
        delta = self.expiry_date - datetime.now().date()
        return delta.days

    def check_expiry_status(self):
        """Update expiry status flags"""
        from datetime import datetime, timedelta
        today = datetime.now().date()
        three_months = today + timedelta(days=90)

        self.is_expired = self.expiry_date < today
        self.is_near_expiry = today <= self.expiry_date <= three_months

    def get_expiration_status(self):
        """Get human-readable expiration status"""
        if self.is_expired:
            return "EXPIRED"
        elif self.is_near_expiry:
            return "NEAR_EXPIRY"
        else:
            return "VALID"

    def save(self, *args, **kwargs):
        # Auto-update expiry flags
        self.check_expiry_status()

        # Auto-update out-of-stock flag
        self.is_out_of_stock = (self.quantity == 0)

        super().save(*args, **kwargs)
    


class MedicationDispense(Base):
    """
    Medication Dispense Model

    Records medication dispensing transactions from pharmacy.

    Usage:
        - Tracks medications given to patients
        - Links prescription to stock deduction
        - Records who dispensed the medication
        - Used for inventory management

    Fields:
        prescribed_medicine: Foreign key to PrescribedMedicine
        stock_entry: Foreign key to MedicationStock (batch tracking)
        quantity_dispensed: Quantity given to patient
        dispensed_date: Date and time of dispensing
        dispensed_by: Pharmacist who dispensed (User FK)
    """
    prescribed_medicine = models.ForeignKey(PrescribedMedicine, on_delete=models.CASCADE)
    stock_entry = models.ForeignKey(MedicationStock, on_delete=models.CASCADE)
    quantity_dispensed = models.PositiveIntegerField()
    dispensed_date = models.DateTimeField(auto_now_add=True)
    dispensed_by = models.ForeignKey(User, on_delete=models.SET_NULL, null=True)

    def __str__(self):
        return f"{self.quantity_dispensed} of {self.stock_entry.medication.name} to {self.prescribed_medicine.consultation.appointment.patient.first_name}"


# ============================================================================
# BILLING MODELS
# ============================================================================
# Author: Athul Gopan
# Purpose: Patient billing, pharmacy billing, and payment management
# ============================================================================

class PatientBill(Base):
    """
    Patient Bill Model

    Generates consolidated bills for patient consultations and medications.

    Usage:
        - Creates final bill after consultation and pharmacy
        - Combines consultation fees and medicine costs
        - Stores patient and doctor information for records
        - Tracks payment status
        - Generates bill receipts

    Fields:
        bill_number: Unique bill identifier (auto-generated)
        patient_name: Patient name (denormalized for reports)
        doctor_name: Doctor name (denormalized for reports)
        consultation: Foreign key to DoctorConsultation
        appointment: Foreign key to Appointment
        bill_date: Bill generation timestamp
        appointment_date/time: Appointment details
        consultation_fee: Doctor's consultation charge
        total_medicine_cost: Total medicine charges
        total_bill_amount: Grand total (auto-calculated)
        medicine_items: JSON array of medicine line items
        payment_status: Payment status (Pending/Paid/Cancelled)
        payment_type: Payment method (Cash/Card/UPI/Other)

    Business Logic:
        - Auto-generates bill_number on save
        - Auto-calculates total_bill_amount
    """
    bill_number = models.CharField(max_length=50, unique=True)

    # Patient and Doctor Information
    patient_name = models.CharField(max_length=255)
    doctor_name = models.CharField(max_length=255)
    
    # Original References (for database integrity)
    consultation = models.OneToOneField(DoctorConsultation, on_delete=models.PROTECT)
    appointment = models.ForeignKey(Appointment, on_delete=models.PROTECT)
    
    # Date Information
    bill_date = models.DateTimeField(auto_now_add=True)
    appointment_date = models.DateField()
    appointment_time = models.TimeField()
    
    # Amount Information
    consultation_fee = models.DecimalField(max_digits=10, decimal_places=2)
    total_medicine_cost = models.DecimalField(max_digits=10, decimal_places=2)
    total_bill_amount = models.DecimalField(max_digits=10, decimal_places=2)
    
    # Store medicine items as JSON
    medicine_items = models.JSONField(default=list)
    
    # Payment Status
    PAYMENT_STATUS_CHOICES = [
        ('PENDING', 'Pending'),
        ('PAID', 'Paid'),
        ('CANCELLED', 'Cancelled'),
    ]

    PAYMENT_TYPE_CHOICES = [
        ('CASH', 'Cash'),
        ('CARD', 'Card'),
        ('UPI', 'UPI'),
        ('OTHER', 'Other')
    ]
    payment_status = models.CharField(max_length=20, choices=PAYMENT_STATUS_CHOICES, default='PENDING')
    payment_type = models.CharField(max_length=20, choices=PAYMENT_TYPE_CHOICES, default='CASH')
    
    class Meta:
        ordering = ['-bill_date']
    
    def __str__(self):
        return f"Bill #{self.bill_number} - {self.patient_name}"
    
    def save(self, *args, **kwargs):
        # Auto-generate bill number if not provided
        if not self.bill_number:
            last_bill = PatientBill.objects.order_by('-id').first()
            if last_bill:
                last_id = int(last_bill.bill_number.split('-')[1])
                self.bill_number = f"BILL-{last_id + 1:06d}"
            else:
                self.bill_number = "BILL-000001"
        
        # Ensure total bill amount is correct
        self.total_bill_amount = self.consultation_fee + self.total_medicine_cost
        
        super().save(*args, **kwargs)


class Pharmacy_Medication(Base):
    appointment = models.ForeignKey(Appointment, on_delete=models.CASCADE)
    medication = models.ForeignKey(Medication, on_delete=models.CASCADE)
    stock_entry = models.ForeignKey(MedicationStock, on_delete=models.CASCADE)
    diagnosis = models.TextField()
    dispensed_date = models.DateTimeField(auto_now_add=True)
    dispensed_by = models.ForeignKey(User, on_delete=models.SET_NULL, null=True ,related_name='dispensed_medications')
    quantity_dispensed = models.PositiveIntegerField()
    dosage = models.CharField(max_length=100)
    frequency = models.CharField(max_length=100)
    duration = models.CharField(max_length=100)


class PharmacyBilling(Base):
    bill_number = models.CharField(max_length=20, unique=True)
    patient_name = models.CharField(max_length=100)
    bill_date = models.DateField(null=True)
    dispensed_by = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, related_name='pharmacy_billing')
    age = models.PositiveIntegerField(null=True)
    gender = models.CharField(max_length=10,null=True)
    discount = models.DecimalField(max_digits=10, decimal_places=2, default=0.00)

    payment_type = models.CharField(
        max_length=20,
        choices=[
            ('CASH', 'Cash'),
            ('CARD', 'Card'),
            ('UPI', 'UPI'),
            ('OTHER', 'Other')
        ],
        default='CASH'
    )

    payment_status = models.CharField(
        max_length=20,
        choices=[
            ('PENDING', 'Pending'),
            ('PAID', 'Paid'),
            ('CANCELLED', 'Cancelled'),
        ],
        default='PENDING'
    )

    amount = models.DecimalField(max_digits=10, decimal_places=2, default=0.00)
    items = models.JSONField(default=list, null=True)
    others = models.JSONField(default=list, null=True)


class PharmacyBillingItem(Base):
    billing = models.ForeignKey(PharmacyBilling, related_name='items_set', on_delete=models.CASCADE)
    medication = models.ForeignKey(Medication, on_delete=models.CASCADE)
    stock_entry = models.ForeignKey(MedicationStock, on_delete=models.SET_NULL, null=True)
    quantity = models.IntegerField()
    unit_price = models.DecimalField(max_digits=10, decimal_places=2, default=0.00,null=True)


# ============================================================================
# LABORATORY MODELS
# ============================================================================
# Author: Athul Gopan
# Purpose: Lab test management, billing, and hierarchical test catalog
# ============================================================================

class LabBilling(Base):
    bill_number = models.CharField(max_length=20, unique=True)
    patient_name = models.CharField(max_length=100)
    bill_date = models.DateField(null=True)
    dispensed_by = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, related_name='Lab_billing')
    age = models.PositiveIntegerField(null=True)
    gender = models.CharField(max_length=10,null=True)
    discount = models.DecimalField(null=True,max_digits=10, decimal_places=2, default=0.00)
 
    payment_type = models.CharField(
        max_length=20,
        choices=[
            ('CASH', 'Cash'),
            ('CARD', 'Card'),
            ('UPI', 'UPI'),
            ('OTHER', 'Other')
        ],
        default='CASH'
    )
 
    payment_status = models.CharField(
        max_length=20,
        choices=[
            ('PENDING', 'Pending'),
            ('PAID', 'Paid'),
            ('CANCELLED', 'Cancelled'),
        ],
        default='PENDING'
    )
 
    amount = models.DecimalField(max_digits=10, decimal_places=2, default=0.00)
    items = models.JSONField(default=list, null=True)


class LabDepartment(Base):
    """
    Lab Department Model

    Represents laboratory departments (e.g., Hematology, Biochemistry).

    Usage:
        - Organizes lab tests by department
        - Stores department-level pricing
        - Links to test categories
    """
    name = models.CharField(max_length=100, unique=True)
    code = models.CharField(max_length=10, unique=True)
    description = models.TextField(blank=True)
    rate = models.PositiveIntegerField(blank=True, null=True)

    def __str__(self):
        return self.name


class TestCategory(models.Model):
    """
    Test Category Model

    Hierarchical categorization of lab tests.

    Usage:
        - Groups related tests (e.g., CBC, Lipid Profile)
        - Supports parent-child hierarchy
        - Links to department and parameters

    Fields:
        department: Parent lab department
        name: Category name
        code: Unique category code
        description: Category details
        parent: Parent category for hierarchical structure

    Example:
        Hematology > CBC > Hemoglobin
    """
    department = models.ForeignKey(LabDepartment, on_delete=models.CASCADE, related_name='categories')
    name = models.CharField(max_length=150)
    code = models.CharField(max_length=20, unique=True)
    description = models.TextField(blank=True)
    parent = models.ForeignKey("self", on_delete=models.CASCADE, related_name='subcategories', null=True, blank=True)

    class Meta:
        unique_together = ['department', 'name']

    def __str__(self):
        return f"{self.department.name} - {self.name}" if not self.parent else f"{self.parent.name} > {self.name}"


class TestParameter(models.Model):
    """
    Test Parameter Model

    Individual test components within a category.

    Usage:
        - Defines specific test parameters (e.g., Hemoglobin, WBC)
        - Stores normal value ranges via ReferenceRange
        - Supports both quantitative and qualitative tests

    Fields:
        category: Parent test category
        name: Parameter name
        code: Parameter code
        unit: Measurement unit (e.g., 'g/dL', 'cells/μL')
        is_qualitative: Boolean for qualitative tests
        normal_values: JSON storage for reference ranges
        sequence_order: Display order in reports
        is_active: Activation status
    """
    category = models.ForeignKey(TestCategory, on_delete=models.CASCADE, related_name='parameters')
    name = models.CharField(max_length=150)
    code = models.CharField(max_length=20)
    unit = models.CharField(max_length=50, blank=True)
    is_qualitative = models.BooleanField(default=False)
    normal_values = models.JSONField(blank=True, null=True)
    sequence_order = models.PositiveIntegerField(default=1)
    is_active = models.BooleanField(default=True)

    class Meta:
        unique_together = ['category', 'code']
        ordering = ['sequence_order', 'name']

    def __str__(self):
        return f"{self.category.name} - {self.name}"


class ReferenceRange(models.Model):
    """
    Reference Range Model

    Defines normal value ranges for test parameters by age/gender.

    Usage:
        - Stores reference ranges for different demographics
        - Supports age and gender-specific ranges
        - Used for flagging abnormal results

    Fields:
        parameter: Foreign key to TestParameter
        gender: Gender category (Male/Female/Other/All)
        age_min/age_max: Age range applicability
        min_val/max_val: Normal value range
        note: Additional notes

    Example:
        Hemoglobin | Male | 18-65yrs : 13.5 - 17.5 g/dL
    """
    parameter = models.ForeignKey(TestParameter, on_delete=models.CASCADE, related_name='reference_ranges')
    gender = models.CharField(max_length=10, choices=[('Male', 'Male'), ('Female', 'Female'), ('Other', 'Other')], blank=True, null=True)
    age_min = models.PositiveIntegerField(blank=True, null=True)
    age_max = models.PositiveIntegerField(blank=True, null=True)
    min_val = models.FloatField()
    max_val = models.FloatField()
    note = models.TextField(blank=True)

    class Meta:
        ordering = ['age_min']

    def __str__(self):
        return f"{self.parameter.name} | {self.gender or 'All'} | {self.age_min or 0}-{self.age_max or '∞'}yrs : {self.min_val} - {self.max_val} {self.parameter.unit}"



# ============================================================================
# ADVANCED PHARMACY MANAGEMENT MODELS
# ============================================================================
# Author: Enhanced Pharmacy Module
# Purpose: Purchase Orders, GRN, Unit Conversion, Stock Returns, Expiry Management
# ============================================================================


class PatientMedicineReturn(Base):
    """
    Patient Medicine Return
    Workflow: PENDING → APPROVED/REJECTED → REFUNDED
    """
    return_number = models.CharField(max_length=50, unique=True, editable=False)
    patient = models.ForeignKey(PatientRegistration, on_delete=models.PROTECT, related_name='medicine_returns')
    original_bill = models.ForeignKey(PharmacyBilling, on_delete=models.SET_NULL, null=True, blank=True, related_name='returns')
    return_date = models.DateField(auto_now_add=True)
    total_refund_amount = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    refund_method = models.CharField(max_length=20, choices=[
        ('CASH', 'Cash'),
        ('CREDIT_NOTE', 'Credit Note'),
        ('ORIGINAL_MODE', 'Original Payment Mode'),
    ], default='CASH')
    status = models.CharField(max_length=20, choices=[
        ('PENDING', 'Pending Approval'),
        ('APPROVED', 'Approved'),
        ('REFUNDED', 'Refunded'),
        ('REJECTED', 'Rejected'),
    ], default='PENDING')

    approved_by = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, blank=True, related_name='approved_patient_returns')
    approval_date = models.DateField(null=True, blank=True)
    notes = models.TextField(blank=True, null=True)
    rejection_reason = models.TextField(blank=True, null=True)

    class Meta:
        ordering = ['-return_date', '-id']

    def __str__(self):
        return f"{self.return_number} - {self.patient.first_name}"

    def save(self, *args, **kwargs):
        if not self.return_number:
            last_return = PatientMedicineReturn.objects.order_by('-id').first()
            if last_return and last_return.return_number:
                try:
                    last_num = int(last_return.return_number.split('-')[1])
                    self.return_number = f"PRET-{last_num + 1:06d}"
                except:
                    self.return_number = "PRET-000001"
            else:
                self.return_number = "PRET-000001"
        super().save(*args, **kwargs)


class PatientMedicineReturnItem(Base):
    """
    Patient Medicine Return Line Items
    """
    patient_return = models.ForeignKey(PatientMedicineReturn, on_delete=models.CASCADE, related_name='items')
    stock_entry = models.ForeignKey(MedicationStock, on_delete=models.PROTECT)
    quantity_returned = models.PositiveIntegerField()
    unit_price = models.DecimalField(max_digits=10, decimal_places=2)
    refund_amount = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    condition = models.CharField(max_length=20, choices=[
        ('UNOPENED', 'Unopened/Sealed'),
        ('OPENED', 'Opened but Usable'),
        ('DAMAGED', 'Damaged'),
    ])
    can_restock = models.BooleanField(default=False)

    def __str__(self):
        return f"{self.stock_entry.medication.name} - {self.quantity_returned} units"

    def save(self, *args, **kwargs):
        self.refund_amount = self.quantity_returned * self.unit_price
        if self.condition == 'UNOPENED':
            self.can_restock = True
        elif self.condition == 'DAMAGED':
            self.can_restock = False
        super().save(*args, **kwargs)


class MedicationReorderConfig(Base):
    """
    Reorder Level Configuration for each medication
    """
    medication = models.OneToOneField(Medication, on_delete=models.CASCADE, related_name='reorder_config')
    reorder_level = models.PositiveIntegerField(default=50)
    reorder_quantity = models.PositiveIntegerField(default=100)
    max_stock_level = models.PositiveIntegerField(default=500)
    lead_time_days = models.PositiveIntegerField(default=7)
    is_auto_reorder = models.BooleanField(default=False)
    # preferred_supplier = models.ForeignKey(Supplier, on_delete=models.SET_NULL, null=True, blank=True)

    def __str__(self):
        return f"{self.medication.name} - Reorder at {self.reorder_level}"


class ExpiryAlertLog(Base):
    """
    Expiry Alert Log - Tracks alerts sent for near-expiry medications
    """
    stock_entry = models.ForeignKey(MedicationStock, on_delete=models.CASCADE, related_name='expiry_alerts')
    alert_type = models.CharField(max_length=20, choices=[
        ('EXPIRED', 'Already Expired'),
        ('CRITICAL', 'Expiring in 30 days'),
        ('WARNING', 'Expiring in 3 months'),
        ('INFO', 'Expiring in 6 months'),
    ])
    expiry_date = models.DateField()
    alert_sent_date = models.DateTimeField(auto_now_add=True)
    alert_recipients = models.JSONField(default=list)
    is_resolved = models.BooleanField(default=False)
    resolution_notes = models.TextField(blank=True, null=True)

    class Meta:
        ordering = ['expiry_date', '-alert_sent_date']

    def __str__(self):
        return f"{self.alert_type} - {self.stock_entry.medication.name} (Expires: {self.expiry_date})"



