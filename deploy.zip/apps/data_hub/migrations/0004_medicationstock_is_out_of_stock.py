# Generated manually for adding is_out_of_stock field

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('data_hub', '0003_medication_brand_name_and_more'),
    ]

    operations = [
        migrations.AddField(
            model_name='medicationstock',
            name='is_out_of_stock',
            field=models.BooleanField(default=False, help_text='Stock is completely out (quantity = 0)'),
        ),
    ]
