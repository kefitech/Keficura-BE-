from django.urls import path
from .views import *

urlpatterns = [
    path('add-nurse/',CreateNurseView.as_view(), name='add-nurse'),
    path('nurse-shift-api/',NurseShiftAssignmentView.as_view(), name='nurse-shift-api'),

]