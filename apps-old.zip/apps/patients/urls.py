from django.urls import path
from .views import *  # Import directly


urlpatterns = [
    path('patient-registration/', PatientRegistrationView.as_view(), name='patient-registration'),
    path('patient-search/',PatientSearchView.as_view(), name='patient-search'),

]

