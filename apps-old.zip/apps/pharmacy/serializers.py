from rest_framework import serializers
from apps.data_hub.models import *
from django.db import transaction
from django.db.models import Sum
from django.utils import timezone




class MedicationSerializer(serializers.ModelSerializer):
    class Meta:
        model = Medication
        exclude = ['created_on', 'updated_on', 'created_by', 'updated_by','description']
        # fields = '__all__'

class MedicationStockSerializer(serializers.ModelSerializer):
    expiration_status = serializers.CharField(source='get_expiration_status', read_only=True)
    days_to_expiry = serializers.IntegerField(source='days_to_expiry', read_only=True)
    current_stock = serializers.IntegerField(source='get_current_stock', read_only=True)

    class Meta:
        model = MedicationStock
        exclude = ['created_on', 'updated_on', 'created_by', 'updated_by']
        # fields = '__all__'
        extra_kwargs = {
            'medication': {'required': True},
            'batch_number': {'required': True},
            'opening_quantity': {'required': False, 'default': 0},
            'received_quantity': {'required': False, 'default': 0},
            'sold_quantity': {'required': False, 'default': 0},
            'returned_quantity': {'required': False, 'default': 0},
            'damaged_quantity': {'required': False, 'default': 0},
            'adjusted_quantity': {'required': False, 'default': 0},
        }

    def validate(self, data):
        """Validate quantity fields"""
        # Ensure quantity fields are non-negative (except adjusted_quantity which can be negative)
        for field in ['opening_quantity', 'received_quantity', 'sold_quantity',
                      'returned_quantity', 'damaged_quantity']:
            if field in data and data[field] < 0:
                raise serializers.ValidationError(f"{field} cannot be negative")
        return data


class DispenseSerializer(serializers.Serializer):
    medication_id = serializers.IntegerField(required=True)
    quantity = serializers.IntegerField(min_value=1, required=True)



class PharmacistSerializer(serializers.ModelSerializer):
    class Meta:
        model = PharmacistStaff
        fields = '__all__'
        
        

class Bill_Serializer(serializers.ModelSerializer):
    class Meta:
        model = PatientBill
        fields = '__all__'



#===============================================Labortary Bill ==========================================#

class DepartmentSerializer(serializers.ModelSerializer):
    class Meta:
        model = LabDepartment
        fields = ['name', 'code', 'description', 'rate']
        
    def validate_name(self, value):
        """Validate department name"""
        if not value or not value.strip():
            raise serializers.ValidationError("Department name cannot be empty")
        return value.strip()
    
    def validate_code(self, value):
        """Validate department code"""
        if not value or not value.strip():
            raise serializers.ValidationError("Department code cannot be empty")
        if len(value.strip()) > 10:
            raise serializers.ValidationError("Department code cannot exceed 10 characters")
        return value.strip().upper()
    
    def validate_rate(self, value):
        """Validate rate if provided"""
        if value is not None and value < 0:
            raise serializers.ValidationError("Rate cannot be negative")
        return value
    
    
    
class TestCategorySerializer(serializers.ModelSerializer):
    class Meta:
        model = TestCategory
        fields = ['department', 'name', 'code', 'description', 'parent']
        
    def validate_name(self, value):
        if not value or not value.strip():
            raise serializers.ValidationError("Category name cannot be empty")
        return value.strip()
    
    def validate_code(self, value):
        if not value or not value.strip():
            raise serializers.ValidationError("Category code cannot be empty")
        if len(value.strip()) > 20:
            raise serializers.ValidationError("Category code cannot exceed 20 characters")
        return value.strip().upper()
    
    def validate_department(self, value):
        if not value:
            raise serializers.ValidationError("Department is required")
        return value
    
    def validate_parent(self, value):
        if value and value.parent:
            raise serializers.ValidationError("Cannot create subcategory under another subcategory")
        return value

class TestParameterSerializer(serializers.ModelSerializer):
    class Meta:
        model = TestParameter
        fields = ['category', 'name', 'code', 'unit', 'is_qualitative', 'normal_values', 'sequence_order', 'is_active']
        
    def validate_name(self, value):
        if not value or not value.strip():
            raise serializers.ValidationError("Parameter name cannot be empty")
        return value.strip()
    
    def validate_code(self, value):
        if not value or not value.strip():
            raise serializers.ValidationError("Parameter code cannot be empty")
        if len(value.strip()) > 20:
            raise serializers.ValidationError("Parameter code cannot exceed 20 characters")
        return value.strip().upper()
    
    def validate_category(self, value):
        if not value:
            raise serializers.ValidationError("Category is required")
        return value
    
    def validate_sequence_order(self, value):
        if value is not None and value < 1:
            raise serializers.ValidationError("Sequence order must be at least 1")
        return value or 1


class ReferenceRangeSerializer(serializers.ModelSerializer):
    class Meta:
        model = ReferenceRange
        fields = ['parameter', 'gender', 'age_min', 'age_max', 'min_val', 'max_val', 'note']
        
    def validate_parameter(self, value):
        if not value:
            raise serializers.ValidationError("Parameter is required")
        return value
    
    def validate_min_val(self, value):
        if value is None:
            raise serializers.ValidationError("Minimum value is required")
        return value
    
    def validate_max_val(self, value):
        if value is None:
            raise serializers.ValidationError("Maximum value is required")
        return value
    
    def validate(self, data):
        if data['min_val'] >= data['max_val']:
            raise serializers.ValidationError("Minimum value must be less than maximum value")
        
        if data.get('age_min') and data.get('age_max'):
            if data['age_min'] >= data['age_max']:
                raise serializers.ValidationError("Minimum age must be less than maximum age")
        
        return data
    
    
 

    

class LabReferenceRangeSerializer(serializers.ModelSerializer):
    age_range_display = serializers.SerializerMethodField()
    range_display = serializers.SerializerMethodField()
    
    class Meta:
        model = ReferenceRange
        fields = ['id', 'gender', 'age_min', 'age_max', 'min_val', 'max_val', 'note', 'age_range_display', 'range_display']
    
    def get_age_range_display(self, obj):
        return f"{obj.age_min or 0}-{obj.age_max or '∞'} years"
    
    def get_range_display(self, obj):
        return f"{obj.min_val} - {obj.max_val} {obj.parameter.unit}"

class LabTestParameterSerializer(serializers.ModelSerializer):
    reference_ranges = LabReferenceRangeSerializer(many=True, read_only=True)
    
    class Meta:
        model = TestParameter
        fields = ['id', 'name', 'code', 'unit', 'is_qualitative', 'normal_values', 'sequence_order', 'reference_ranges']

class LabTestCategorySerializer(serializers.ModelSerializer):
    subcategories = serializers.SerializerMethodField()
    parameters = LabTestParameterSerializer(many=True, read_only=True)
    
    class Meta:
        model = TestCategory
        fields = ['id', 'name', 'code', 'description', 'subcategories', 'parameters']
    
    def get_subcategories(self, obj):
        subcategories = obj.subcategories.all()
        return TestCategorySerializer(subcategories, many=True).data

class LabDepartmentSerializer(serializers.ModelSerializer):
    categories = serializers.SerializerMethodField()
    
    class Meta:
        model = LabDepartment
        fields = ['id', 'name', 'code', 'description', 'rate', 'categories']
    
    def get_categories(self, obj):
        # Only get main categories (without parent)
        main_categories = obj.categories.filter(parent__isnull=True)
        return LabTestCategorySerializer(main_categories, many=True).data
    













