from django.urls import path
from .views import *  # Import directly

urlpatterns = [
    path('frontdesk_profile/',FrontdeskProfileView.as_view(), name='frontdesk_profile'),
    

]






