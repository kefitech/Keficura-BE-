from django.shortcuts import render
from django.contrib.auth.models import User , Group
from rest_framework.response import Response
from utils.auth_helper import *
from utils.email_helper import *
from apps.data_hub.models import * 
from .serializers import *
from rest_framework.views import APIView
from django.db import transaction
from rest_framework import viewsets, status, permissions



class FrontdeskProfileView(APIView):
    """
    API view to create a new user and Front desk profile simultaneously
    """
    permission_classes = [IsAdminUser]
    @transaction.atomic
    def post(self, request):
        """
        Creates a new user and associated Front desk profile
        """
        username = request.data.get('username')
        email = request.data.get('email')
        password = request.data.get('password')
        first_name = request.data.get('first_name')
        last_name = request.data.get('last_name')
        
        if not username or not email or not password:
            return Response(
                {"detail": "Username, email and password are required"}, 
                status=status.HTTP_400_BAD_REQUEST
            )
        
        if User.objects.filter(username=username).exists():
            return Response(
                {"detail": "Username already exists"}, 
                status=status.HTTP_400_BAD_REQUEST
            )
        
        if User.objects.filter(email=email).exists():
            return Response(
                {"detail": "Email already exists"}, 
                status=status.HTTP_400_BAD_REQUEST
            )
        
        try:
            user = User.objects.create_user(
                username=username,
                email=email,
                password=password,
                first_name=first_name,
                last_name=last_name
               )
            
            front_desk_group = Group.objects.get(id=4)
            user.groups.add(front_desk_group)
            user.save()
            
        except Group.DoesNotExist:
            user.delete()
            return Response(
                {"detail": "Doctor group with ID 2 does not exist"}, 
                status=status.HTTP_400_BAD_REQUEST
            )
        except Exception as e:
            return Response(
                {"detail": f"Failed to create user: {str(e)}"}, 
                status=status.HTTP_400_BAD_REQUEST
            )

        front_desk_data = {
            'user': user.id,
            'date_of_birth': request.data.get('date_of_birth'),
            'gender': request.data.get('gender'),
            'hire_date': request.data.get('hire_date'),

            'contact_number': request.data.get('contact_number'),
            'email': email,
            'employee_id':request.data.get('employee_id'),

            # 'home_address': request.data.get('home_address'),
            # 'home_city': request.data.get('home_city'),
            # 'home_state': request.data.get('home_state'),
            # 'home_country': request.data.get('home_country'),
            # 'home_zip_code': request.data.get('home_zip_code'),

            'shift_schedule': request.data.get('shift_schedule'),
        }
        
        # If profile picture was included
        if 'profile_picture' in request.FILES:
            front_desk_data['profile_picture'] = request.FILES['profile_picture']
        
        serializer = FrontDeskSerializer(data=front_desk_data)
        if serializer.is_valid():
            nurse = serializer.save()  
            
            try:
                # send_doctor_credentials_email.delay(
                #     email=user.email,
                #     first_name=user.first_name,
                #     last_name=user.last_name,
                #     username=username,
                #     password=password
                # )       
                send_doctor_credentials_email(
                    email=user.email,
                    first_name=user.first_name,
                    last_name=user.last_name,
                    username=username,
                    password=password
                )           
                response_data = {
                    "message": "Nurse profile created successfully. Credentials have been sent to their respective email."
                }

            except Exception as e:
                # print(f"Failed to send email: {str(e)}")
                response_data = {
                    "message": "Nurse profile created successfully, but failed to send email with credentials.",
                    "warning": "Please provide the Nurse with their credentials manually.",
                    "credentials": {
                        "username": username,
                        "password": password
                    }
                }
            return Response(response_data, status=status.HTTP_201_CREATED)
        else:
            user.delete()
            return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)






        
