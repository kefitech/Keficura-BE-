from django.urls import path
from .views import *

urlpatterns = [
    # ============================================================================
    # SUPPLIER MANAGEMENT URLs
    # ============================================================================
    path('suppliers/', SupplierView.as_view(), name='supplier-list-create'),
    path('suppliers/<int:supplier_id>/', SupplierView.as_view(), name='supplier-detail'),
    path('suppliers/search/', SupplierSearchView.as_view(), name='supplier-search'),

    # ============================================================================
    # PURCHASE ORDER URLs
    # ============================================================================
    path('purchase-orders/', PurchaseOrderView.as_view(), name='purchase-order-list-create'),
    path('purchase-orders/<int:po_id>/', PurchaseOrderView.as_view(), name='purchase-order-detail'),
    path('purchase-orders/<int:po_id>/approve/', PurchaseOrderApproveView.as_view(), name='purchase-order-approve'),

    # ============================================================================
    # PURCHASE ENTRY (GRN) URLs
    # ============================================================================
    path('purchase-entries/', PurchaseEntryView.as_view(), name='purchase-entry-list-create'),
    path('purchase-entries/<int:grn_id>/', PurchaseEntryView.as_view(), name='purchase-entry-detail'),
    path('purchase-entries/<int:grn_id>/items/', PurchaseEntryItemsView.as_view(), name='purchase-entry-items'),

    # ============================================================================
    # SUPPLIER RETURN (PURCHASE RETURN) URLs
    # ============================================================================
    path('supplier-returns/', SupplierReturnView.as_view(), name='supplier-return-list-create'),
    path('supplier-returns/<int:return_id>/', SupplierReturnView.as_view(), name='supplier-return-detail'),
    path('supplier-returns/<int:return_id>/approve/', SupplierReturnApproveView.as_view(), name='supplier-return-approve'),
    path('supplier-returns/<int:return_id>/items/', SupplierReturnItemsView.as_view(), name='supplier-return-items'),

    # ============================================================================
    # EXISTING URLs
    # ============================================================================
    path('pharmacist_profile/', PharmacistProfileView.as_view(), name='pharmacist_profile'),
    path('medications/', MedicationView.as_view(), name='medications'),
    path('stock/', MedicationStockView.as_view(), name='medication-stock'),
    path('dispense/', DispenseView.as_view(), name='dispense-medication'),
    path('consultations/', DoctorConsultationView.as_view(), name='consultation-list-create'),
    path('patient-history/<str:patient_id>/', PatientHistoryView.as_view(), name='patient-history'),
    path('doctor-prescribed-medicine/', PharmaPrescribedMedicineView.as_view(), name='pharma-prescribed-medicine'),
    path('pharma-consultation/',PharmaConsultationView.as_view(), name='pharma-consultation'),
    path('pharma-medicine-dispense/',PrescribedMedicationDispense.as_view(), name='pharma-consultation'),
    path('bill-preview/', FinalBillPreviewView.as_view(), name='bill-preview'),
    path('bill-consultation/', BillingConsultationView.as_view(), name='bill-consultation'),
    path ('save-bill/', Generated_bill_save.as_view(), name='save-bill'),
    #==================================================================================================
    # path('pharma-appointments/',Appointment_Pharmacy_View.as_view(),name='pharma-appointments'),
    # path('pharma-med-entry/',Pharmacy_Medication_Management.as_view(),name='pharma-med-entry'),
    path('pharma-available-meds/', MedicationListView.as_view(),name='pharma-available-meds'),
    # path('bill-preview/', FinalSampleBillPreviewView.as_view(), name='bill-preview'),
    path('bill-history/',PaymentHistoryView.as_view(),name='bill-history'),
    path('pharma-bill/',Pharmacy_Items.as_view(),name='pharma-bill'),
    path('doctor-med/',MedicationList.as_view(),name='ddoctor-med'),
    path('lab-billing/', Lab_Items.as_view(), name='lab-billing'),

       #Lab Department URLS
    path('lab-department/create/', DepartmentCreateView.as_view(), name='department-create'),
    path('lab-department/<int:department_id>/', DepartmentCreateView.as_view(), name='department-update'),
    # Test Category URLS
    path('test-category/create', TestCategoryCreateView.as_view(), name='test-category-create'),
    path('test-category/<int:category_id>/', TestCategoryCreateView.as_view(), name='test-category-update'),
    # Test Parameter URLS
    path('test-parameters/create/', TestParameterCreateView.as_view(), name='test-parameter-create'),
    path('test-parameters/<int:parameter_id>/', TestParameterCreateView.as_view(), name='test-parameter-update'),
    # Reference Range URLS
    path('reference-ranges/create/', ReferenceRangeCreateView.as_view(), name='reference-range-create'),
    path('reference-ranges/<int:range_id>/', ReferenceRangeCreateView.as_view(), name='reference-range-update'),
    #List of lab test available URLS
    path('lab-test-data/', LabDepartmentSerializerView.as_view(), name='reference-range-list'),

    # Audit Log URLS
    path('stock-audit-log/', MedicationStockAuditLogView.as_view(), name='stock-audit-log'),

    # Inventory Reports & Analytics URLS
    path('reports/inventory-valuation/', InventoryValuationReportView.as_view(), name='inventory-valuation-report'),
    path('reports/fast-moving/', FastMovingMedicationsReportView.as_view(), name='fast-moving-report'),
    path('reports/slow-moving/', SlowMovingMedicationsReportView.as_view(), name='slow-moving-report'),
    path('reports/stock-aging/', StockAgingReportView.as_view(), name='stock-aging-report'),
    path('reports/expiry-alerts/', ExpiryAlertReportView.as_view(), name='expiry-alert-report'),
    path('reports/low-stock-alerts/', LowStockAlertReportView.as_view(), name='low-stock-alert-report'),
]