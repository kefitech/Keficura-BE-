from django.urls import path
from .views import *  # Import directly

urlpatterns = [
    path('login/', LoginView.as_view(), name='login'),  
    path('menu/',MenuMapping.as_view(),name='menu'),
    path('admin/',Admin_registrationView.as_view(),name='admin')

]
