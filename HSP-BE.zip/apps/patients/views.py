from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from rest_framework import viewsets, permissions
from apps.data_hub.models import *
from .serializers import PatientSerializer
from utils.auth_helper import *
from rest_framework.response import Response
from rest_framework import viewsets, status
from rest_framework.views import APIView
from utils.auth_unique_id import *




 #========================================================================================================#
 #                                         Patient Views                                                  #
 #========================================================================================================#
class PatientRegistrationView(APIView):
    # permission_classes = [IsReceptionist]

    def post(self, request, *args, **kwargs):
        """
        Handles patient registration
        """
        try:
            patient_id = get_next_patient_id()
            print(patient_id,"idddddddddddddddddd") 
            
            patient_data = {
                **request.data,
                "patient_id": patient_id
            }
            serializer = PatientSerializer(data=patient_data)
            serializer.is_valid(raise_exception=True)
            serializer.save(created_by=request.user)
            
            return Response(
                {
                    "status": "success",
                    "patient_id": patient_id,
                    "data": serializer.data
                },
                status=status.HTTP_201_CREATED
            )

        except Exception as e:
            return Response(
                {
                    "status": "error",
                    "message": str(e)
                },
                status=status.HTTP_400_BAD_REQUEST
            )        

class PatientSearchView(APIView):
    # permission_classes = [IsReceptionist]
    """handles patient search for getting the patient details and last 3 appointments"""
    def post(self, request):
        try:
            contact_number = request.data.get('patient_phone_number')
        
            if not contact_number:
                return Response(
                    {"error": "Patient phone number is required"}, 
                    status=status.HTTP_400_BAD_REQUEST
                )
            
            patients = PatientRegistration.objects.filter(contact_number=contact_number,created_by=request.user)
            if not patients.exists():
                return Response(
                    {"error": "No patients found with the provided phone number"}, 
                    status=status.HTTP_404_NOT_FOUND
                )
            results = []
            for patient in patients:
                appointments = Appointment.objects.filter(
                    patient=patient
                ).order_by('-appointment_date', '-appointment_time')[:3]                
                patient_data = {
                    "patient_id": patient.id,
                    "name": f"{patient.first_name} {patient.last_name}",
                    "date_of_birth": patient.date_of_birth,
                    "age": patient.age,
                    "gender": patient.get_gender_display(),
                    "contact_number": patient.contact_number,
                    "email": patient.email,
                    "address": patient.address,
                    "allergies": patient.allergies,
                    "emergency_contact": patient.emergency_contact,
                    "registration_date": patient.registration_date,
                    "insurance_details": {
                        "provider": patient.insurance_provider,
                        "number": patient.insurance_number
                    }
                }                
                appointment_data = []
                for appointment in appointments:
                    appointment_data.append({
                        "appointment_id": appointment.appointment_id,
                        "doctor": f"Dr. {appointment.doctor.user.first_name}",
                        "date": appointment.appointment_date,
                        "time": appointment.appointment_time,
                        "reason": appointment.visit_reason,
                        "status": appointment.visit_status,
                        "room": appointment.consultation_room
                    })
                results.append({
                    "patient": patient_data,
                    "recent_appointments": appointment_data
                })
            response_data = {
                "count": len(results),
                "results": results
            }
            
            return Response(response_data, status=status.HTTP_200_OK)
            
        except Exception as e:
            return Response(
                {"error": f"An error occurred: {str(e)}"}, 
                status=status.HTTP_500_INTERNAL_SERVER_ERROR
            )