from rest_framework.permissions import BasePermission
from apps.data_hub.models import * 

import logging

# Set up logging
logger = logging.getLogger(__name__)


class IsDoctor(BasePermission):
    """
    Permission to only allow doctors to access the view.
    """
    def has_permission(self, request, view):
        return (
            request.user and
            request.user.groups.filter(name="Doctor").exists()
        )

class IsNurse(BasePermission):
    print("adminnnnnnnnnnnn")
    """
    Permission to only allow nurses to access the view.
    """
    def has_permission(self, request, view):
        return (
            request.user and
            request.user.is_authenticated and
            request.user.groups.filter(name="Nurse").exists()
        )

class IsReceptionist(BasePermission):
    """
    Permission to only allow receptionists to access the view.
    """
    def has_permission(self, request, view):
        return (
            request.user and
            request.user.is_authenticated and
            request.user.groups.filter(name="Receptionist").exists()
        )
class IsPharmacist(BasePermission):
    """
    Permission to only allow pharmacists to access the view.
    """
    def has_permission(self, request, view):
        return (
            request.user and
            request.user.is_authenticated and
            request.user.groups.filter(name="Pharmacist").exists()
        )
class IsAdminUser(BasePermission):
    """
    Permission to only allow admin users to access the view.
    """
    def has_permission(self, request, view):
        return (
            request.user and
            request.user.is_authenticated and
            request.user.groups.filter(name="Administrator").exists()
        )

class IsSuperAdmin(BasePermission):
    """
    Permission to only allow super admin users to access the view.
    """
    def has_permission(self, request, view):
        print(" inside  super admin permission")
        print(request.user.groups.filter(name="SuperAdministrator").exists())
        return (
            request.user and
            request.user.is_authenticated and
            request.user.groups.filter(name="SuperAdministrator").exists()
            )
    


# -----------------------------------------------MENU FETCH LOGIC ------------------------------------

def get_user_menu_items(user, user_groups):
    """
    Get menu items accessible to the user based on their group permissions.
    Returns a hierarchical menu structure with group information and active state.
    Also handles feature availability based on user's roles.
    """
    if user.is_superuser:
        # Superuser gets all menu items
        all_menu_items = Menu.objects.filter().order_by('menu_order')
    else:
        # Get menu IDs accessible to user's groups
        permitted_menu_ids = MenuPermissionMapper.objects.filter(
            auth_group_permission__in=user_groups,
            is_active=True
        ).values_list('menu_id', flat=True)
        
        # Get all accessible menu items
        all_menu_items = Menu.objects.filter(
            id__in=permitted_menu_ids,
            is_active=True
        ).order_by('menu_order')
    
    # Create a hierarchical menu structure
    root_menus = []
    menu_dict = {}
    
    # Get all user group IDs for quick access checking
    user_group_ids = set(user_groups.values_list('id', flat=True))
    
    # First pass: create dictionary of all menu items
    for menu in all_menu_items:
        # Get all groups associated with this menu
        menu_groups = MenuPermissionMapper.objects.filter(
            menu=menu,
            is_active=True
        ).select_related('auth_group_permission')
        
        
        groups_info = []
        is_accessible = user.is_superuser  
        
        for menu_group in menu_groups:
            if menu_group.auth_group_permission:
                group_info = {
                    'id': menu_group.auth_group_permission.id,
                    'name': menu_group.auth_group_permission.name,
                    'permission_id': menu_group.id 
                }
                groups_info.append(group_info)
                
                # Check if user has this group for accessibility
                if menu_group.auth_group_permission.id in user_group_ids:
                    is_accessible = True
        
        # Build menu data with accessibility flag
        menu_data = {
            'id': menu.id,
            'name': menu.name,
            'title': menu.title,
            'code': menu.code,
            'redirect_url': menu.redirect_url,
            'icon': menu.icon,
            'menu_order': menu.menu_order,
            'feature_code': menu.feature_code,
            'is_active': menu.is_active and is_accessible,  # Set active based on permissions
            'is_accessible': is_accessible,  # Additional flag for frontend
            'groups': groups_info,
            'children': []
        }
        menu_dict[menu.id] = menu_data
    
    # Second pass: build hierarchy
    for menu in all_menu_items:
        menu_data = menu_dict[menu.id]
        if menu.parent_id is None:
            # This is a root menu
            root_menus.append(menu_data)
        elif menu.parent_id in menu_dict:
            # This is a child menu
            menu_dict[menu.parent_id]['children'].append(menu_data)
    
    # Sort root menus and children by menu_order
    root_menus.sort(key=lambda x: x['menu_order'])
    for menu_data in menu_dict.values():
        menu_data['children'].sort(key=lambda x: x['menu_order'])
    
    return root_menus

# ----------------------------------------Menu fetch logic end -----------------------------------------