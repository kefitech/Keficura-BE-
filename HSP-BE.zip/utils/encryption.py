from cryptography.fernet import Fernet
from django.conf import settings
import base64
import os

# Generate or use existing key (store in settings.SECRET_KEY or environment variable)
ENCRYPTION_KEY = settings.ENCRYPTION_KEY or Fernet.generate_key()

def encrypt_data(data: str) -> str:
    f = Fernet(ENCRYPTION_KEY)
    encrypted_data = f.encrypt(data.encode())
    return encrypted_data.decode()

def decrypt_data(encrypted_data: str) -> str:
    f = Fernet(ENCRYPTION_KEY)
    decrypted_data = f.decrypt(encrypted_data.encode())
    return decrypted_data.decode()