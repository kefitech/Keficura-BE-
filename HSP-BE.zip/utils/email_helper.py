from django.core.mail import send_mail
from django.conf import settings
from celery import shared_task

@shared_task(bind=True, max_retries=3)
def send_doctor_credentials_email(self, email, first_name, last_name, username, password):
    try:
        print("mail sendddddd")
        subject = 'Your Doctor Portal Account Credentials'
        message = f"""
        Dear Dr. {first_name or ''} {last_name or ''},

        Your account has been successfully created on our Doctor Portal.

        Here are your login credentials:
        Username: {username}
        Password: {password}

        Please keep this information secure and consider changing your password after first login.

        Best regards,
        Hospital Administration Team
        """

        send_mail(
            subject,
            message.strip(),
            settings.DEFAULT_FROM_EMAIL,
            [email],
            fail_silently=False,
        )
    
    except Exception as e:
        print(e,"error.........")
        raise self.retry(exc=e, countdown=60)


