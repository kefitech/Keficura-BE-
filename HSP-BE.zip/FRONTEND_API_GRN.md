# Frontend API Documentation - GRN (Purchase Entry) System

**Session 3 APIs - For React Integration**

---

## 🔌 Base URL
```
http://localhost:8000/api/pharmacy
```

---

## 📋 Table of Contents
1. [Create GRN (with items)](#1-create-grn-with-items)
2. [List All GRNs (with filters)](#2-list-all-grns-with-filters)
3. [Get Single GRN Details](#3-get-single-grn-details)
4. [Update GRN (Payment)](#4-update-grn-payment)
5. [Delete GRN](#5-delete-grn-soft-delete)
6. [Get GRN Items Only](#6-get-grn-items-only)

---

## 1. Create GRN (with items)

### **Endpoint**
```
POST /api/pharmacy/purchase-entries/
```

### **Headers**
```javascript
{
  "Authorization": "Bearer <your_token>",
  "Content-Type": "application/json"
}
```

### **Request Body**
```json
{
  "supplier": 1,
  "purchase_order": 1,
  "invoice_number": "INV-2025-1234",
  "invoice_date": "2025-12-02",
  "received_date": "2025-12-02",
  "discount_amount": 500.00,
  "payment_status": "PENDING",
  "payment_mode": null,
  "payment_date": null,
  "notes": "Urgent delivery received",
  "items": [
    {
      "medication": 5,
      "batch_number": "PCM-2025-045",
      "expiry_date": "2027-12-31",
      "quantity": 500,
      "free_quantity": 50,
      "packing": "10x10 Strips",
      "mrp": 50.00,
      "purchase_price": 35.00,
      "ptr": 40.00,
      "discount_percent": 5.00,
      "cgst_percent": 6.00,
      "sgst_percent": 6.00,
      "igst_percent": 0.00
    },
    {
      "medication": 12,
      "batch_number": "ASP-2025-089",
      "expiry_date": "2026-06-30",
      "quantity": 300,
      "free_quantity": 30,
      "packing": "20x10 Tablets",
      "mrp": 30.00,
      "purchase_price": 20.00,
      "ptr": 25.00,
      "discount_percent": 10.00,
      "cgst_percent": 6.00,
      "sgst_percent": 6.00,
      "igst_percent": 0.00
    }
  ]
}
```

### **Field Descriptions**

#### **GRN Header Fields:**
| Field | Type | Required | Description |
|-------|------|----------|-------------|
| `supplier` | integer | ✅ Yes | Supplier ID |
| `purchase_order` | integer | ❌ Optional | Link to PO (can be null) |
| `invoice_number` | string | ✅ Yes | Supplier invoice number |
| `invoice_date` | date (YYYY-MM-DD) | ✅ Yes | Invoice date |
| `received_date` | date (YYYY-MM-DD) | ✅ Yes | Date goods received |
| `discount_amount` | decimal | ❌ Optional | Additional discount on total (default: 0) |
| `payment_status` | string | ❌ Optional | PENDING/PARTIAL/PAID (default: PENDING) |
| `payment_mode` | string | ❌ Optional | CASH/CARD/UPI/CHEQUE/NEFT (null if not paid) |
| `payment_date` | date | ❌ Optional | Date of payment (null if not paid) |
| `notes` | string | ❌ Optional | Additional notes |
| `items` | array | ✅ Yes | Array of purchase items (min 1 item) |

#### **Item Fields:**
| Field | Type | Required | Description |
|-------|------|----------|-------------|
| `medication` | integer | ✅ Yes | Medication ID |
| `batch_number` | string | ✅ Yes | Manufacturer batch code |
| `expiry_date` | date (YYYY-MM-DD) | ✅ Yes | Expiry date (must be future) |
| `quantity` | integer | ✅ Yes | Quantity purchased |
| `free_quantity` | integer | ❌ Optional | Bonus/free quantity (default: 0) |
| `packing` | string | ❌ Optional | Packing info (e.g., "10x10 Strips") |
| `mrp` | decimal | ✅ Yes | Maximum Retail Price |
| `purchase_price` | decimal | ✅ Yes | Our buying price (must be ≤ MRP) |
| `ptr` | decimal | ❌ Optional | Price to Retailer (wholesale) |
| `discount_percent` | decimal | ❌ Optional | Discount % (default: 0) |
| `cgst_percent` | decimal | ❌ Optional | Central GST % (default: 0) |
| `sgst_percent` | decimal | ❌ Optional | State GST % (default: 0) |
| `igst_percent` | decimal | ❌ Optional | Integrated GST % (default: 0) |

### **Success Response (201 Created)**
```json
{
  "message": "Purchase entry created successfully",
  "grn_id": 1,
  "grn_number": "GRN-20251202-0001"
}
```

### **Error Response (400 Bad Request)**
```json
{
  "error": "Validation failed",
  "details": {
    "items": ["At least one item is required"],
    "invoice_number": ["This field is required"],
    "expiry_date": ["Expiry date must be in the future"]
  }
}
```

### **React Example (Axios)**
```javascript
import axios from 'axios';

const createGRN = async (grnData) => {
  try {
    const response = await axios.post(
      'http://localhost:8000/api/pharmacy/purchase-entries/',
      grnData,
      {
        headers: {
          'Authorization': `Bearer ${localStorage.getItem('token')}`,
          'Content-Type': 'application/json'
        }
      }
    );

    console.log('GRN Created:', response.data);
    // { grn_id: 1, grn_number: "GRN-20251202-0001", message: "..." }

    return response.data;
  } catch (error) {
    console.error('Error:', error.response.data);
    throw error;
  }
};

// Usage
const grnData = {
  supplier: 1,
  invoice_number: "INV-2025-1234",
  invoice_date: "2025-12-02",
  received_date: "2025-12-02",
  items: [
    {
      medication: 5,
      batch_number: "PCM-2025-045",
      expiry_date: "2027-12-31",
      quantity: 500,
      free_quantity: 50,
      mrp: 50.00,
      purchase_price: 35.00,
      cgst_percent: 6.00,
      sgst_percent: 6.00
    }
  ]
};

createGRN(grnData);
```

---

## 2. List All GRNs (with filters)

### **Endpoint**
```
GET /api/pharmacy/purchase-entries/
```

### **Query Parameters (All Optional)**
| Parameter | Type | Description | Example |
|-----------|------|-------------|---------|
| `supplier_id` | integer | Filter by supplier | `?supplier_id=1` |
| `purchase_order_id` | integer | Filter by PO | `?purchase_order_id=1` |
| `payment_status` | string | PENDING/PARTIAL/PAID | `?payment_status=PENDING` |
| `invoice_number` | string | Exact match | `?invoice_number=INV-2025-1234` |
| `start_date` | date | From date (received_date) | `?start_date=2025-12-01` |
| `end_date` | date | To date (received_date) | `?end_date=2025-12-31` |
| `page` | integer | Page number (default: 1) | `?page=2` |
| `page_size` | integer | Items per page (default: 20, max: 100) | `?page_size=50` |

### **Example URLs**
```
# All GRNs
GET /api/pharmacy/purchase-entries/

# Pending payments only
GET /api/pharmacy/purchase-entries/?payment_status=PENDING

# Supplier's GRNs in December 2025
GET /api/pharmacy/purchase-entries/?supplier_id=1&start_date=2025-12-01&end_date=2025-12-31

# GRNs linked to PO
GET /api/pharmacy/purchase-entries/?purchase_order_id=5

# Search by invoice number
GET /api/pharmacy/purchase-entries/?invoice_number=INV-2025-1234

# Pagination
GET /api/pharmacy/purchase-entries/?page=2&page_size=20
```

### **Success Response (200 OK)**
```json
{
  "count": 45,
  "next": "http://localhost:8000/api/pharmacy/purchase-entries/?page=3",
  "previous": "http://localhost:8000/api/pharmacy/purchase-entries/?page=1",
  "results": [
    {
      "id": 1,
      "grn_number": "GRN-20251202-0001",
      "supplier": 1,
      "supplier_name": "MedPharma Distributors",
      "purchase_order": 1,
      "purchase_order_number": "PO-20251202-0001",
      "invoice_number": "INV-2025-1234",
      "invoice_date": "2025-12-02",
      "received_date": "2025-12-02",
      "subtotal": "21450.00",
      "discount_amount": "2050.00",
      "tax_amount": "2574.00",
      "total_amount": "24024.00",
      "payment_status": "PENDING",
      "payment_status_display": "Pending",
      "payment_mode": null,
      "payment_date": null,
      "items_count": 2,
      "is_active": true,
      "created_by_name": "admin",
      "created_on": "2025-12-02T10:30:00Z"
    },
    {
      "id": 2,
      "grn_number": "GRN-20251201-0001",
      "supplier": 2,
      "supplier_name": "Apollo Distributors",
      "purchase_order": null,
      "purchase_order_number": null,
      "invoice_number": "APOLLO-INV-5678",
      "invoice_date": "2025-12-01",
      "received_date": "2025-12-01",
      "subtotal": "15000.00",
      "discount_amount": "0.00",
      "tax_amount": "1800.00",
      "total_amount": "16800.00",
      "payment_status": "PAID",
      "payment_status_display": "Paid",
      "payment_mode": "NEFT",
      "payment_date": "2025-12-05",
      "items_count": 3,
      "is_active": true,
      "created_by_name": "pharmacy_staff",
      "created_on": "2025-12-01T14:20:00Z"
    }
  ]
}
```

### **React Example**
```javascript
const fetchGRNs = async (filters = {}) => {
  try {
    // Build query string
    const params = new URLSearchParams();
    if (filters.supplier_id) params.append('supplier_id', filters.supplier_id);
    if (filters.payment_status) params.append('payment_status', filters.payment_status);
    if (filters.start_date) params.append('start_date', filters.start_date);
    if (filters.end_date) params.append('end_date', filters.end_date);
    if (filters.page) params.append('page', filters.page);
    if (filters.page_size) params.append('page_size', filters.page_size);

    const response = await axios.get(
      `http://localhost:8000/api/pharmacy/purchase-entries/?${params.toString()}`,
      {
        headers: {
          'Authorization': `Bearer ${localStorage.getItem('token')}`
        }
      }
    );

    return response.data;
  } catch (error) {
    console.error('Error:', error);
    throw error;
  }
};

// Usage examples
// All GRNs
const allGRNs = await fetchGRNs();

// Pending payments only
const pendingGRNs = await fetchGRNs({ payment_status: 'PENDING' });

// Supplier's GRNs in date range
const supplierGRNs = await fetchGRNs({
  supplier_id: 1,
  start_date: '2025-12-01',
  end_date: '2025-12-31'
});
```

---

## 3. Get Single GRN Details

### **Endpoint**
```
GET /api/pharmacy/purchase-entries/{grn_id}/
```

### **Example URL**
```
GET /api/pharmacy/purchase-entries/1/
```

### **Success Response (200 OK)**
```json
{
  "id": 1,
  "grn_number": "GRN-20251202-0001",
  "supplier": 1,
  "supplier_name": "MedPharma Distributors",
  "purchase_order": 1,
  "purchase_order_number": "PO-20251202-0001",
  "invoice_number": "INV-2025-1234",
  "invoice_date": "2025-12-02",
  "received_date": "2025-12-02",
  "subtotal": "21450.00",
  "discount_amount": "2550.00",
  "tax_amount": "2574.00",
  "total_amount": "24024.00",
  "payment_status": "PENDING",
  "payment_status_display": "Pending",
  "payment_mode": null,
  "payment_date": null,
  "notes": "Urgent delivery received",
  "is_active": true,
  "items_count": 2,
  "purchase_items": [
    {
      "id": 1,
      "medication": 5,
      "medication_name": "Paracetamol 500mg",
      "batch_number": "PCM-2025-045",
      "expiry_date": "2027-12-31",
      "quantity": 500,
      "free_quantity": 50,
      "packing": "10x10 Strips",
      "mrp": "50.00",
      "purchase_price": "35.00",
      "ptr": "40.00",
      "discount_percent": "5.00",
      "discount_amount": "1750.00",
      "cgst_percent": "6.00",
      "sgst_percent": "6.00",
      "igst_percent": "0.00",
      "tax_amount": "1890.00",
      "total_amount": "17640.00",
      "margin_percent": "30.00",
      "stock_entry": 123
    },
    {
      "id": 2,
      "medication": 12,
      "medication_name": "Aspirin 75mg",
      "batch_number": "ASP-2025-089",
      "expiry_date": "2026-06-30",
      "quantity": 300,
      "free_quantity": 30,
      "packing": "20x10 Tablets",
      "mrp": "30.00",
      "purchase_price": "20.00",
      "ptr": "25.00",
      "discount_percent": "10.00",
      "discount_amount": "600.00",
      "cgst_percent": "6.00",
      "sgst_percent": "6.00",
      "igst_percent": "0.00",
      "tax_amount": "684.00",
      "total_amount": "6384.00",
      "margin_percent": "33.33",
      "stock_entry": 124
    }
  ],
  "created_by": 1,
  "created_by_name": "admin",
  "created_on": "2025-12-02T10:30:00Z",
  "updated_by": null,
  "updated_by_name": null,
  "updated_on": "2025-12-02T10:30:00Z"
}
```

### **Error Response (404 Not Found)**
```json
{
  "error": "Purchase entry not found"
}
```

### **React Example**
```javascript
const fetchGRNDetail = async (grnId) => {
  try {
    const response = await axios.get(
      `http://localhost:8000/api/pharmacy/purchase-entries/${grnId}/`,
      {
        headers: {
          'Authorization': `Bearer ${localStorage.getItem('token')}`
        }
      }
    );

    return response.data;
  } catch (error) {
    console.error('Error:', error);
    throw error;
  }
};

// Usage
const grnDetail = await fetchGRNDetail(1);
console.log('GRN Number:', grnDetail.grn_number);
console.log('Items:', grnDetail.purchase_items);
```

---

## 4. Update GRN (Payment)

### **Endpoint**
```
PATCH /api/pharmacy/purchase-entries/{grn_id}/
```

### **Note**: Only payment-related fields can be updated. Items CANNOT be modified after GRN creation.

### **Example URL**
```
PATCH /api/pharmacy/purchase-entries/1/
```

### **Request Body (Update Payment)**
```json
{
  "payment_status": "PAID",
  "payment_mode": "NEFT",
  "payment_date": "2025-12-10"
}
```

### **Request Body (Update Discount)**
```json
{
  "discount_amount": 1000.00
}
```

### **Request Body (Add Notes)**
```json
{
  "notes": "Payment received via bank transfer"
}
```

### **Updatable Fields:**
| Field | Type | Description |
|-------|------|-------------|
| `payment_status` | string | PENDING/PARTIAL/PAID |
| `payment_mode` | string | CASH/CARD/UPI/CHEQUE/NEFT |
| `payment_date` | date | Date of payment |
| `discount_amount` | decimal | Additional discount (will recalculate totals) |
| `notes` | string | Additional notes |

### **Success Response (200 OK)**
```json
{
  "message": "Purchase entry updated successfully",
  "grn_id": 1,
  "grn_number": "GRN-20251202-0001"
}
```

### **React Example**
```javascript
const updateGRNPayment = async (grnId, paymentData) => {
  try {
    const response = await axios.patch(
      `http://localhost:8000/api/pharmacy/purchase-entries/${grnId}/`,
      paymentData,
      {
        headers: {
          'Authorization': `Bearer ${localStorage.getItem('token')}`,
          'Content-Type': 'application/json'
        }
      }
    );

    return response.data;
  } catch (error) {
    console.error('Error:', error);
    throw error;
  }
};

// Usage - Mark as paid
await updateGRNPayment(1, {
  payment_status: 'PAID',
  payment_mode: 'NEFT',
  payment_date: '2025-12-10'
});

// Usage - Update discount
await updateGRNPayment(1, {
  discount_amount: 1000.00
});
```

---

## 5. Delete GRN (Soft Delete)

### **Endpoint**
```
DELETE /api/pharmacy/purchase-entries/{grn_id}/
```

### **Note**: This is a soft delete. GRN and related stock entries are marked as `is_active=false`.

### **Example URL**
```
DELETE /api/pharmacy/purchase-entries/1/
```

### **Success Response (200 OK)**
```json
{
  "message": "Purchase entry deleted successfully"
}
```

### **Error Response (404 Not Found)**
```json
{
  "error": "Purchase entry not found"
}
```

### **React Example**
```javascript
const deleteGRN = async (grnId) => {
  try {
    const response = await axios.delete(
      `http://localhost:8000/api/pharmacy/purchase-entries/${grnId}/`,
      {
        headers: {
          'Authorization': `Bearer ${localStorage.getItem('token')}`
        }
      }
    );

    return response.data;
  } catch (error) {
    console.error('Error:', error);
    throw error;
  }
};

// Usage with confirmation
const handleDelete = async (grnId) => {
  if (window.confirm('Are you sure you want to delete this GRN?')) {
    await deleteGRN(grnId);
    alert('GRN deleted successfully');
  }
};
```

---

## 6. Get GRN Items Only

### **Endpoint**
```
GET /api/pharmacy/purchase-entries/{grn_id}/items/
```

### **Example URL**
```
GET /api/pharmacy/purchase-entries/1/items/
```

### **Success Response (200 OK)**
```json
{
  "grn_id": 1,
  "grn_number": "GRN-20251202-0001",
  "items_count": 2,
  "items": [
    {
      "id": 1,
      "medication": 5,
      "medication_name": "Paracetamol 500mg",
      "batch_number": "PCM-2025-045",
      "expiry_date": "2027-12-31",
      "quantity": 500,
      "free_quantity": 50,
      "packing": "10x10 Strips",
      "mrp": "50.00",
      "purchase_price": "35.00",
      "ptr": "40.00",
      "discount_percent": "5.00",
      "discount_amount": "1750.00",
      "cgst_percent": "6.00",
      "sgst_percent": "6.00",
      "igst_percent": "0.00",
      "tax_amount": "1890.00",
      "total_amount": "17640.00",
      "margin_percent": "30.00",
      "stock_entry": 123
    },
    {
      "id": 2,
      "medication": 12,
      "medication_name": "Aspirin 75mg",
      "batch_number": "ASP-2025-089",
      "expiry_date": "2026-06-30",
      "quantity": 300,
      "free_quantity": 30,
      "packing": "20x10 Tablets",
      "mrp": "30.00",
      "purchase_price": "20.00",
      "ptr": "25.00",
      "discount_percent": "10.00",
      "discount_amount": "600.00",
      "cgst_percent": "6.00",
      "sgst_percent": "6.00",
      "igst_percent": "0.00",
      "tax_amount": "684.00",
      "total_amount": "6384.00",
      "margin_percent": "33.33",
      "stock_entry": 124
    }
  ]
}
```

### **React Example**
```javascript
const fetchGRNItems = async (grnId) => {
  try {
    const response = await axios.get(
      `http://localhost:8000/api/pharmacy/purchase-entries/${grnId}/items/`,
      {
        headers: {
          'Authorization': `Bearer ${localStorage.getItem('token')}`
        }
      }
    );

    return response.data;
  } catch (error) {
    console.error('Error:', error);
    throw error;
  }
};

// Usage
const itemsData = await fetchGRNItems(1);
console.log('Items:', itemsData.items);
```

---

## 🎯 Complete React Component Example

```javascript
import React, { useState, useEffect } from 'react';
import axios from 'axios';

const API_BASE_URL = 'http://localhost:8000/api/pharmacy';

const GRNManagement = () => {
  const [grns, setGRNs] = useState([]);
  const [loading, setLoading] = useState(false);
  const [filters, setFilters] = useState({
    payment_status: '',
    supplier_id: '',
    start_date: '',
    end_date: ''
  });

  // Fetch GRNs with filters
  const fetchGRNs = async () => {
    setLoading(true);
    try {
      const params = new URLSearchParams();
      Object.keys(filters).forEach(key => {
        if (filters[key]) params.append(key, filters[key]);
      });

      const response = await axios.get(
        `${API_BASE_URL}/purchase-entries/?${params.toString()}`,
        {
          headers: {
            'Authorization': `Bearer ${localStorage.getItem('token')}`
          }
        }
      );

      setGRNs(response.data.results);
    } catch (error) {
      console.error('Error fetching GRNs:', error);
      alert('Failed to fetch GRNs');
    } finally {
      setLoading(false);
    }
  };

  // Create new GRN
  const createGRN = async (grnData) => {
    try {
      const response = await axios.post(
        `${API_BASE_URL}/purchase-entries/`,
        grnData,
        {
          headers: {
            'Authorization': `Bearer ${localStorage.getItem('token')}`,
            'Content-Type': 'application/json'
          }
        }
      );

      alert(`GRN Created: ${response.data.grn_number}`);
      fetchGRNs(); // Refresh list
      return response.data;
    } catch (error) {
      console.error('Error creating GRN:', error.response.data);
      alert('Failed to create GRN');
      throw error;
    }
  };

  // Update payment status
  const updatePayment = async (grnId, paymentData) => {
    try {
      await axios.patch(
        `${API_BASE_URL}/purchase-entries/${grnId}/`,
        paymentData,
        {
          headers: {
            'Authorization': `Bearer ${localStorage.getItem('token')}`,
            'Content-Type': 'application/json'
          }
        }
      );

      alert('Payment updated successfully');
      fetchGRNs(); // Refresh list
    } catch (error) {
      console.error('Error updating payment:', error);
      alert('Failed to update payment');
    }
  };

  // Delete GRN
  const deleteGRN = async (grnId) => {
    if (!window.confirm('Are you sure you want to delete this GRN?')) return;

    try {
      await axios.delete(
        `${API_BASE_URL}/purchase-entries/${grnId}/`,
        {
          headers: {
            'Authorization': `Bearer ${localStorage.getItem('token')}`
          }
        }
      );

      alert('GRN deleted successfully');
      fetchGRNs(); // Refresh list
    } catch (error) {
      console.error('Error deleting GRN:', error);
      alert('Failed to delete GRN');
    }
  };

  useEffect(() => {
    fetchGRNs();
  }, [filters]);

  return (
    <div>
      <h1>GRN Management</h1>

      {/* Filters */}
      <div className="filters">
        <select
          value={filters.payment_status}
          onChange={(e) => setFilters({...filters, payment_status: e.target.value})}
        >
          <option value="">All Payment Status</option>
          <option value="PENDING">Pending</option>
          <option value="PARTIAL">Partial</option>
          <option value="PAID">Paid</option>
        </select>

        <input
          type="date"
          value={filters.start_date}
          onChange={(e) => setFilters({...filters, start_date: e.target.value})}
          placeholder="Start Date"
        />

        <input
          type="date"
          value={filters.end_date}
          onChange={(e) => setFilters({...filters, end_date: e.target.value})}
          placeholder="End Date"
        />
      </div>

      {/* GRN List */}
      {loading ? (
        <p>Loading...</p>
      ) : (
        <table>
          <thead>
            <tr>
              <th>GRN Number</th>
              <th>Supplier</th>
              <th>Invoice</th>
              <th>Date</th>
              <th>Total</th>
              <th>Payment Status</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {grns.map(grn => (
              <tr key={grn.id}>
                <td>{grn.grn_number}</td>
                <td>{grn.supplier_name}</td>
                <td>{grn.invoice_number}</td>
                <td>{grn.received_date}</td>
                <td>₹{grn.total_amount}</td>
                <td>{grn.payment_status_display}</td>
                <td>
                  <button onClick={() => {/* View details */}}>View</button>
                  {grn.payment_status === 'PENDING' && (
                    <button onClick={() => updatePayment(grn.id, {
                      payment_status: 'PAID',
                      payment_mode: 'NEFT',
                      payment_date: new Date().toISOString().split('T')[0]
                    })}>
                      Mark Paid
                    </button>
                  )}
                  <button onClick={() => deleteGRN(grn.id)}>Delete</button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </div>
  );
};

export default GRNManagement;
```

---

## 📋 Quick Reference

### **Payment Status Values**
- `PENDING` - Not paid yet
- `PARTIAL` - Partially paid
- `PAID` - Fully paid

### **Payment Mode Values**
- `CASH` - Cash payment
- `CARD` - Card payment
- `UPI` - UPI payment
- `CHEQUE` - Cheque payment
- `NEFT` - Bank transfer

### **Date Format**
All dates should be in `YYYY-MM-DD` format (e.g., `2025-12-02`)

### **Decimal Format**
All amounts should be decimal numbers with 2 decimal places (e.g., `50.00`, `1234.56`)

---

## 🔍 Testing Tips

1. **Use Postman/Thunder Client** for initial API testing
2. **Check browser console** for detailed error messages
3. **Verify token** is valid and not expired
4. **Check network tab** to see actual request/response
5. **Validate dates** are in correct format
6. **Ensure supplier/medication IDs exist** before creating GRN

---

## ✅ What Happens Automatically

When you create a GRN via API:
- ✅ GRN number auto-generated (GRN-20251202-0001)
- ✅ Item totals auto-calculated (discount, GST, total)
- ✅ GRN totals auto-calculated (subtotal, tax, grand total)
- ✅ Margin % auto-calculated ((MRP - purchase_price) / MRP × 100)
- ✅ **MedicationStock entries auto-created** (one per item)
- ✅ Stock linked to GRN and item
- ✅ PurchaseOrder status auto-updated (if linked)
- ✅ Expiry status auto-checked
- ✅ Audit fields auto-set (created_by, created_on)

**You don't need to:**
- ❌ Calculate totals manually
- ❌ Create stock entries manually
- ❌ Update PO status manually
- ❌ Set audit fields manually

Everything is handled by the backend! 🎉
